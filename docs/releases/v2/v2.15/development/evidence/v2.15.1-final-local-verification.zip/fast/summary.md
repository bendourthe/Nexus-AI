# fast

Status: PASS

| Group | Status | Duration ms |
| --- | --- | ---: |
| npm run lint | PASS | 25446 |
| node bin/nexus-check.mjs --baseline configs/nexus-check-baseline.json | PASS | 685 |
| node scripts/check-command-parity.mjs | PASS | 78 |
| node scripts/check-release-assets.mjs | PASS | 63 |
| node scripts/check-docs-layout.mjs | PASS | 46 |
