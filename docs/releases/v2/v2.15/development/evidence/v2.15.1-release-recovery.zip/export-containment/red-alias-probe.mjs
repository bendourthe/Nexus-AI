﻿import { startVitest } from 'vitest/node';
import { appendFileSync, readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join, resolve } from 'node:path';
const proof=process.env.NEXUS_PROOF_DIR;
const log=join(proof,'red-alias-reproduction.log');
const source=resolve('tests/sidecar-node/image-edit-agent.test.ts');
const production=resolve('sidecar/src/studio/imageEditRuntime.ts');
const hash=path=>createHash('sha256').update(readFileSync(path)).digest('hex');
const before={test:hash(source),production:hash(production)};
for(const stream of [process.stdout,process.stderr]){const original=stream.write.bind(stream);stream.write=(chunk,...args)=>{appendFileSync(log,chunk);return original(chunk,...args);};}
let transformations=0;
const ctx=await startVitest('test',['tests/sidecar-node/image-edit-agent.test.ts'],{config:'vitest.config.ts',watch:false,reporters:['dot'],testNamePattern:'previews and exports through the renderer with the pinned source, never overwriting'}, {plugins:[{name:'private-temp-parent-alias-reproduction',enforce:'pre',transform(code,id){if(!id.replaceAll('\\','/').endsWith('/tests/sidecar-node/image-edit-agent.test.ts'))return;
const fixture='const exportsRoot = join(root, "exports");';
const assertion='expect(exported.path!.startsWith(f.exportsRoot.replace(/\\\\/g, "/")) || exported.path!.startsWith(f.exportsRoot)).toBe(true);';
if(!code.includes(fixture)||!code.includes(assertion))throw Error('Reproduction anchors changed');
transformations++;
code=code.replace('readdirSync, renameSync','readdirSync, realpathSync, renameSync');
code=code.replace(fixture,'const physicalParent = join(root, "canonical-export-parent"); mkdirSync(physicalParent); const alias = join(root, "temp-parent-alias"); symlinkSync(physicalParent, alias, process.platform === "win32" ? "junction" : "dir"); const exportsRoot = join(alias, "exports");');
code=code.replace(assertion,'console.log(JSON.stringify({fixtureExportsRoot:f.exportsRoot,canonicalExportsRoot:realpathSync(f.exportsRoot),actualExportPath:exported.path,lexicalPrefixMatches:exported.path!.startsWith(f.exportsRoot)})); '+assertion);
return {code,map:null};}}]});
function failedLeaves(tasks){return tasks.reduce((count,task)=>count+(task.type==='test'&&task.result?.state==='fail'?1:0)+failedLeaves(task.tasks??[]),0);}
const failed=failedLeaves(ctx.state.getFiles());
await ctx.close();
const after={test:hash(source),production:hash(production)};
const receipt={at:new Date().toISOString(),kind:'in-memory fixture-only alias reproduction',command:'node --input-type=module (stdin is red-alias-probe.mjs)',commandSha256:hash(join(proof,'red-alias-probe.mjs')),before,after,transformations,failedTests:failed,expectedFailedTests:1,sourceFilesChanged:JSON.stringify(before)!==JSON.stringify(after),log};
writeFileSync(join(proof,'red-alias-receipt.json'),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({proofDirectory:proof,failedTests:failed,unchanged:!receipt.sourceFilesChanged}));
process.exitCode=transformations===1&&failed===1&&!receipt.sourceFilesChanged?0:1;
