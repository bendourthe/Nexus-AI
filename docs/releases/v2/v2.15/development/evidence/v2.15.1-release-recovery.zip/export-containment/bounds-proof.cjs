﻿const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'nexus-export-bounds-'));
assert.equal(fs.realpathSync(path.dirname(root)),fs.realpathSync(os.tmpdir()));
const proof=process.env.NEXUS_PROOF_DIR;
let receipt;
try {
const owned=path.join(root,'exports'),alias=path.join(root,'temp-parent-alias'),outside=path.join(root,'exports-sibling'),nested=path.join(owned,'nested');
fs.mkdirSync(nested,{recursive:true});fs.mkdirSync(outside);fs.symlinkSync(root,alias,process.platform==='win32'?'junction':'dir');
const files={owned:path.join(owned,'out.png'),sibling:path.join(outside,'out.png'),nested:path.join(nested,'out.png')};
for(const file of Object.values(files))fs.writeFileSync(file,'fixture');
const lexicalRoot=path.join(alias,'exports');
const contained=file=>path.dirname(fs.realpathSync(file))===fs.realpathSync(lexicalRoot);
assert.equal(contained(files.owned),true);assert.equal(contained(path.join(lexicalRoot,'out.png')),true);
assert.equal(contained(files.sibling),false);assert.equal(contained(files.nested),false);
assert.equal(files.sibling.startsWith(owned),true);
receipt={at:new Date().toISOString(),ordinaryDirectChild:contained(files.owned),aliasedDirectChild:contained(path.join(lexicalRoot,'out.png')),siblingRefused:!contained(files.sibling),nestedRefused:!contained(files.nested),oldPrefixWouldAcceptSibling:files.sibling.startsWith(owned),fixtureWorkspace:root,commandSha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(proof,'bounds-proof.cjs'))).digest('hex')};
} finally {fs.rmSync(root,{recursive:true,force:true});}
receipt.fixtureRemoved=!fs.existsSync(root);
fs.writeFileSync(path.join(proof,'bounds-receipt.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
