import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
const O=path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/,'$1'));
const installed='C:/nx-close/node_modules';
const req=createRequire(pathToFileURL(installed+'/semantic-release/index.js'));
const semantic=(await import(pathToFileURL(installed+'/semantic-release/index.js'))).default;
const analyze=(await import(pathToFileURL(installed+'/@semantic-release/commit-analyzer/index.js'))).analyzeCommits;
const generate=(await import(pathToFileURL(installed+'/@semantic-release/release-notes-generator/index.js'))).generateNotes;
const changelog=req(installed+'/@semantic-release/changelog/lib/prepare.js');
const npmPrepare=(await import(pathToFileURL(installed+'/@semantic-release/npm/lib/prepare.js'))).default;
const gitPrepare=req(installed+'/@semantic-release/git/lib/prepare.js');
const id=JSON.parse(fs.readFileSync(path.join(O,'identity.json')));
const env=Object.fromEntries(['PATH','Path','SystemRoot','SYSTEMROOT','WINDIR','ComSpec','COMSPEC','PATHEXT','SystemDrive','PROCESSOR_ARCHITECTURE','NUMBER_OF_PROCESSORS'].filter(k=>process.env[k]).map(k=>[k,process.env[k]]));
Object.assign(env,{HOME:O,USERPROFILE:O,TEMP:O,TMP:O,APPDATA:O,LOCALAPPDATA:O,GIT_CONFIG_GLOBAL:path.join(O,'empty.gitconfig'),GIT_CONFIG_NOSYSTEM:'1',GIT_TERMINAL_PROMPT:'0',GIT_AUTHOR_NAME:id.name,GIT_AUTHOR_EMAIL:id.email,GIT_COMMITTER_NAME:id.name,GIT_COMMITTER_EMAIL:id.email,NPM_CONFIG_UPDATE_NOTIFIER:'false',NPM_CONFIG_AUDIT:'false',NPM_CONFIG_FUND:'false'});
assert(!Object.keys(env).some(k=>/TOKEN|PASSWORD|SECRET|ASKPASS/.test(k)));
const log=fs.createWriteStream(path.join(O,'qualification.log'));
const logger=Object.fromEntries(['log','warn','error','success'].map(k=>[k,(...a)=>log.write(k+': '+a.join(' ')+'\n')]));
function git(cwd,...a){assert(path.resolve(cwd).startsWith(path.resolve(O)+path.sep));return execFileSync('git',a,{cwd,env,encoding:'utf8',stdio:['ignore','pipe','pipe']}).trim();}
function write(p,s){fs.writeFileSync(p,s);}
function json(p){return JSON.parse(fs.readFileSync(p));}
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const files=['CHANGELOG.md','package.json','package-lock.json'];
const hashes=cwd=>Object.fromEntries(files.map(n=>[n,hash(path.join(cwd,n))]));
function clone(remote,name){const p=path.join(O,name);git(remote,'clone',remote,p);git(p,'config','commit.gpgsign','false');git(p,'config','tag.gpgsign','false');git(p,'config','core.hooksPath',path.join(O,'empty-hooks'));return p;}
fs.mkdirSync(path.join(O,'empty-hooks'));
function protect(remote){
 const attempt=path.join(remote,'attempted-refs.log').replaceAll('\\','/');const accepted=path.join(remote,'accepted-refs.log').replaceAll('\\','/');
 write(path.join(remote,'hooks/pre-receive'),`#!/bin/sh\nwhile read old new ref; do\n echo "$old $new $ref" >> '${attempt}'\n if [ "$ref" = refs/heads/main ]; then echo QUALIFICATION_REJECT_PROTECTED_MAIN >&2; exit 1; fi\ndone\n`);
 write(path.join(remote,'hooks/post-receive'),`#!/bin/sh\nwhile read old new ref; do echo "$old $new $ref" >> '${accepted}'; done\n`);
}
const url=remote=>pathToFileURL(remote).href;
function options(remote,guard={},dryRun=false){return {branches:['main'],tagFormat:'v${version}',repositoryUrl:url(remote),ci:false,dryRun,plugins:[{analyzeCommits:analyze},{generateNotes:async(c,ctx)=>{const notes=await generate(c,ctx);if(guard.notes!==undefined)assert.equal(notes,guard.notes,'notes drift');return notes;}},{verifyRelease:async(c,ctx)=>{assert.equal(ctx.nextRelease.version,guard.version||'2.15.1');},prepare:async(c,ctx)=>{
 assert(!guard.publisherActive,'concurrent publisher');assert.equal(ctx.branch.name,'main');assert.equal(git(ctx.cwd,'branch','--show-current'),'main');assert.equal(git(ctx.cwd,'rev-parse','HEAD'),guard.head);assert.equal(git(ctx.cwd,'ls-remote',remote,'refs/heads/main').split(/\s/)[0],guard.head,'remote main drift');assert.equal(ctx.nextRelease.gitHead,guard.head);assert.equal(git(ctx.cwd,'status','--porcelain','--untracked-files=all'),'');assert.deepEqual(hashes(ctx.cwd),guard.hashes);assert.equal(json(path.join(ctx.cwd,'package.json')).version,'2.15.1');assert.equal(json(path.join(ctx.cwd,'package-lock.json')).packages[''].version,'2.15.1');assert(fs.readFileSync(path.join(ctx.cwd,'CHANGELOG.md'),'utf8').startsWith(ctx.nextRelease.notes.trim()+'\n'));}}]};}
async function core(cwd,remote,guard={},dryRun=false){return semantic(options(remote,guard,dryRun),{cwd,env,stdout:log,stderr:log});}
async function prepare(cwd,remote,notes){const context={cwd,env,stdout:log,stderr:log,logger,nextRelease:{version:'2.15.1',gitTag:'v2.15.1',notes},branch:{name:'main'},options:{repositoryUrl:url(remote)},lastRelease:{version:'2.15.0'}};await changelog({changelogFile:'CHANGELOG.md'},context);await npmPrepare(path.join(O,'empty.npmrc'),{},context);return context;}
write(path.join(O,'empty.npmrc'),'');
const failRemote=path.join(O,'original-remote.git');fs.mkdirSync(failRemote);git(failRemote,'init','--bare','--initial-branch=main');const seed=clone(failRemote,'seed');
write(path.join(seed,'package.json'),JSON.stringify({name:'fixture-nexus',version:'2.15.0',private:true},null,2)+'\n');write(path.join(seed,'package-lock.json'),JSON.stringify({name:'fixture-nexus',version:'2.15.0',lockfileVersion:3,requires:true,packages:{'':{name:'fixture-nexus',version:'2.15.0'}}},null,2)+'\n');write(path.join(seed,'CHANGELOG.md'),'# 2.15.0\n\nPrior release.\n');
git(seed,'add','.');git(seed,'commit','-m','chore: baseline');git(seed,'tag','v2.15.0');write(path.join(seed,'source.txt'),'checkpoint repair\n');git(seed,'add','.');git(seed,'commit','-m','fix: repair checkpoint persistence');git(seed,'push','--all','origin');git(seed,'push','--tags','origin');
const originalHead=git(failRemote,'rev-parse','main');protect(failRemote);const original=clone(failRemote,'original-prepare');const analyzed=await core(original,failRemote,{},true);assert.equal(analyzed.nextRelease.version,'2.15.1');const ctx=await prepare(original,failRemote,analyzed.nextRelease.notes);let rejection;
try{await gitPrepare({assets:files,message:'chore(release): ${nextRelease.version} [skip ci]\n\n${nextRelease.notes}'},ctx);assert.fail('protected main push unexpectedly accepted');}catch(e){rejection=String(e.stderr||e.message);assert(rejection.includes('QUALIFICATION_REJECT_PROTECTED_MAIN'));}
assert.equal(git(failRemote,'rev-parse','main'),originalHead);assert.notEqual(git(original,'rev-parse','HEAD'),originalHead);
const remote=path.join(O,'prepared-remote.git');git(failRemote,'clone','--bare',failRemote,remote);git(remote,'symbolic-ref','HEAD','refs/heads/main');const prep=clone(remote,'metadata-preparation');const prepAnalysis=await core(prep,remote,{},true);await prepare(prep,remote,prepAnalysis.nextRelease.notes);assert.deepEqual(git(prep,'diff','--name-only').split('\n').sort(),[...files].sort());git(prep,'add',...files);git(prep,'commit','-m','chore(release): prepare v2.15.1');git(prep,'push','origin','main');const head=git(remote,'rev-parse','main');protect(remote);
const canonical=clone(remote,'green-main');const expected=hashes(canonical);const stableNotes=await core(canonical,remote,{},true);assert.equal(stableNotes.nextRelease.version,'2.15.1');assert.equal(stableNotes.nextRelease.notes,prepAnalysis.nextRelease.notes);
const guards={head,notes:stableNotes.nextRelease.notes,hashes:expected};const negative=[];
for(const [name,change] of [['wrong-version',{version:'2.15.2'}],['wrong-notes',{notes:'different notes'}],['wrong-head',{head:'0'.repeat(40)}],['concurrent-publisher',{publisherActive:true}]]){
 const cwd=clone(remote,'negative-'+name);let failed=false;try{await core(cwd,remote,{...guards,...change});}catch(e){failed=true;}assert(failed,name);assert.equal(git(remote,'rev-parse','main'),head);assert.equal(git(cwd,'rev-parse','HEAD'),head);assert.equal(git(cwd,'status','--porcelain'),'');negative.push({name,refused:true,noHeadAdvance:true});
}
const dirty=clone(remote,'negative-dirty-metadata');write(path.join(dirty,'CHANGELOG.md'),'altered notes\n');let dirtyFailed=false;try{await core(dirty,remote,guards);}catch(e){dirtyFailed=true;}assert(dirtyFailed);negative.push({name:'dirty-metadata',refused:true,noHeadAdvance:git(dirty,'rev-parse','HEAD')===head});
const branch=clone(remote,'negative-branch');git(branch,'checkout','-b','feature-unsupported');assert.equal(await core(branch,remote,guards),false);negative.push({name:'not-main',refused:true,noHeadAdvance:git(branch,'rev-parse','HEAD')===head});
assert.equal(git(remote,'tag','--list','v2.15.1'),'');
const beforeRefs=git(remote,'show-ref');const result=await core(canonical,remote,guards);assert.equal(result.nextRelease.version,'2.15.1');assert.equal(result.nextRelease.notes,guards.notes);assert.equal(result.nextRelease.gitHead,head);assert.equal(git(canonical,'rev-parse','HEAD'),head);assert.equal(git(remote,'rev-parse','main'),head);assert.deepEqual(hashes(canonical),expected);assert.equal(git(canonical,'status','--porcelain','--untracked-files=all'),'');assert.equal(git(remote,'rev-parse','v2.15.1'),head);
const accepted=fs.readFileSync(path.join(remote,'accepted-refs.log'),'utf8').trim().split('\n').map(x=>x.split(' ').at(-1));assert.deepEqual(accepted.sort(),['refs/notes/semantic-release-v2.15.1','refs/tags/v2.15.1'].sort());write(path.join(O,'actual-core-result.json'),JSON.stringify(result,null,2)+'\n');
const report={status:'PASS',installedSemanticRelease:JSON.parse(fs.readFileSync(installed+'/semantic-release/package.json')).version,originalGitPrepare:{rejected:true,remoteMainUnchanged:true,reason:'QUALIFICATION_REJECT_PROTECTED_MAIN',attemptedRefs:fs.readFileSync(path.join(failRemote,'attempted-refs.log'),'utf8')},preparedMetadataFiles:files,negativeGuards:negative,version:result.nextRelease.version,notesExact:true,mainOnly:true,currentGreenMainChecked:true,headBefore:head,headAfter:git(canonical,'rev-parse','HEAD'),remoteMainUnchanged:true,metadataHashes:expected,noFileChanges:true,noNewCommit:true,beforeRefs,afterRefs:git(remote,'show-ref'),acceptedRefWrites:accepted,semanticCoreReleaseResults:result.releases,publishPlugins:[],githubReleaseCreated:false,unsolicitedIssueOrPrMessages:false,callableOptions:{branches:['main'],tagFormat:'v${version}',repositoryUrl:'fixture-local-file-only',ci:false,dryRun:false,plugins:['installedanalyzer','installednotesgenerator','inline-readonlyverifyRelease+prepareguard']},scope:'Localfixture proves tags/notes core only. No actualGitHubauthority, CIorpublication result; actualgreenmain/normalPR/terminalpublisher preconditions remain external mandatory.'};
write(path.join(O,'qualification.json'),JSON.stringify(report,null,2)+'\n');log.end();console.log(JSON.stringify({status:'PASS',output:O,version:report.version,negativeGuards:negative.length,acceptedRefWrites:accepted,noNewCommit:true,githubReleaseCreated:false}));
