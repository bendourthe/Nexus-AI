from pathlib import Path
import hashlib,json,subprocess,sys,time
w=Path(__file__).resolve().parent;freeze=json.loads((w/'source-freeze.json').read_text())
def audit():return {n:hashlib.sha256((w/'scripts'/n).read_bytes()).hexdigest() for n in freeze['sha256']}
if audit()!=freeze['sha256']:raise RuntimeError('source drift before final qualification')
if any(hashlib.sha256((w/n).read_bytes()).hexdigest()!=h for n,h in freeze['test_sha256'].items()):raise RuntimeError('test drift')
args=[sys.executable,'-B','-m','pytest','-q',*freeze['test_sha256'],'--tb=short','--junitxml',str(w/'qualification.junit.xml')]
start=time.monotonic();r=subprocess.run(args,cwd=w,capture_output=True,text=True)
(w/'qualification.log').write_text(r.stdout+r.stderr,encoding='utf-8')
value={'command':args,'cwd':str(w),'exit_code':r.returncode,'elapsed_seconds':round(time.monotonic()-start,3),'sha256_before':freeze['sha256'],'sha256_after':audit(),'private_only':True,'production_mutations':False}
(w/'qualification.json').write_text(json.dumps(value,indent=2),encoding='utf-8')
print(json.dumps({'exit_code':r.returncode,'elapsed_seconds':value['elapsed_seconds'],'source_stable':value['sha256_before']==value['sha256_after']}))
if r.returncode:print((r.stdout+r.stderr)[-6000:])
raise SystemExit(r.returncode or (0 if value['sha256_before']==value['sha256_after'] else 1))
