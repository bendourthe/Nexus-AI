from pathlib import Path
import json
import pytest
from test_exact_link_variants import repo, pair, ck, cm, mc, PLAN, FOREIGN, V05, V06, SESSION
from validators.test_gap_migration_and_archive import LINK_CHECKER
from validators.test_check_plan_completion import _git
from validators.test_completion_minor_record import _no_transport_overrides
from validators.test_check_plan_completion import _isolated_git_config


def command(repo, token, plan, *extra):
    return repo.close('archive','--minor',token,'--plan',str(repo.work / plan),'--session',SESSION,'--link-checker',str(LINK_CHECKER),*extra)


def test_real_both_dryruns_then_ordered_apply_keeps_foreign_record_exact(pair):
    repo, records, pages = pair
    foreign_ctx=ck.Context(str(repo.work / FOREIGN),ck.Budget(180))
    foreign_path=foreign_ctx.record_path()
    raw=foreign_path.read_bytes()
    result=command(repo,'v0.6',FOREIGN,'--closing-branch','chore/close-v0.5')
    assert result.returncode==0,result.stdout+result.stderr
    assert 'CONDITIONAL ARCHIVE READY v0.6 required-before=v0.5' in result.stdout
    assert 'WOULD ARCHIVE' not in result.stdout
    refused=command(repo,'v0.6',FOREIGN,'--apply','--closing-branch','chore/close-v0.5')
    assert refused.returncode==3 and 'archive-order-required' in refused.stdout,refused.stdout+refused.stderr
    assert foreign_path.read_bytes()==raw
    dry=command(repo,'v0.5',PLAN)
    assert dry.returncode==0 and 'WOULD ARCHIVE v0.5' in dry.stdout,dry.stdout+dry.stderr
    result=command(repo,'v0.5',PLAN,'--apply')
    assert result.returncode==0,result.stdout+result.stderr
    assert foreign_path.read_bytes()==raw
    current=ck.Context(str(repo.work / FOREIGN),ck.Budget(180))
    assert ck.load_record(current,SESSION).forced is None
    assert repo.read(FOREIGN)==mc.relocated_link_text(records[FOREIGN]['approvals']['archive_evidence']['link_relocation'])
    _git(repo.work,'checkout','-q','-b','chore/close-v0.6')
    result=command(repo,'v0.6',FOREIGN,'--apply')
    assert result.returncode==0,result.stdout+result.stderr
    archived=FOREIGN.replace('docs/releases/','docs/archives/',1)
    current=ck.Context(str(repo.work / archived),ck.Budget(180))
    loaded=ck.load_record(current,SESSION)
    assert loaded.forced is None and loaded.record is not None
    assert loaded.record['approvals']['archive_evidence']['link_relocation']==records[FOREIGN]['approvals']['archive_evidence']['link_relocation']
    assert current.plan_hash_matches(loaded.record['plan_sha256'])
