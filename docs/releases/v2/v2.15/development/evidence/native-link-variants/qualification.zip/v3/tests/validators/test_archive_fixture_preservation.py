from pathlib import Path
import hashlib
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "scripts"))
import minor_close as mc


@pytest.mark.parametrize("suffix", ["json", "md", "ts", "html", "txt"])
def test_archive_does_not_repair_logical_paths_in_test_fixtures(suffix):
    path = f"tests/fixtures/captured/known-gaps.{suffix}"
    assert not mc.link_eligible(path)
    assert not mc.mention_eligible(path)


def test_archive_preserves_fixture_bytes_and_repairs_operational_paths(tmp_path):
    old = "docs/releases/v2/v2.13"
    new = "docs/archives/v2/v2.13"
    files = {
        "tests/fixtures/captured/discovery.json": f'{{"path":"{old}/contract.json"}}\r\n',
        "tests/fixtures/captured/known-gaps.md": f"[Captured](../../../{old}/contract.json)\r\n\r\nOriginal: {old}/contract.json\r\n",
        "tests/fixtures/captured/README.md": f"[Captured](../../../{old}/contract.json)\n",
        "tests/unit/operational.test.ts": f'const contract = "{old}/contract.json";\n',
        "scripts/operational.mjs": f'const contract = "{old}/contract.json";\n',
        "docs/reference/README.md": f"[Contract](../releases/v2/v2.13/contract.json)\n",
        "docs/handbooks/example.md": f"[Contract](../releases/v2/v2.13/contract.json)\n",
        "tests/fixtures-live/operational.ts": f'const contract = "{old}/contract.json";\n',
        f"{old}/contract.json": "{}\n",
    }
    fixture_hashes = {}
    for rel, text in files.items():
        path = tmp_path / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(text.encode())
        if rel.startswith("tests/fixtures/"):
            fixture_hashes[rel] = hashlib.sha256(path.read_bytes()).hexdigest()
    mapping = [(p, p, new + p[len(old):] if p.startswith(old + "/") else p) for p in files]
    repairs = mc.plan_repairs(tmp_path, mapping, old, new)
    repaired = {r.new_rel: r for r in repairs}
    assert set(repaired) == {
        "tests/unit/operational.test.ts", "scripts/operational.mjs",
        "docs/reference/README.md", "docs/handbooks/example.md",
        "tests/fixtures-live/operational.ts",
    }
    for rel, repair in repaired.items():
        assert new + "/contract.json" in repair.repaired or "archives/v2/v2.13/contract.json" in repair.repaired
        (tmp_path / rel).write_bytes(repair.repaired.encode())
    for rel, digest in fixture_hashes.items():
        assert hashlib.sha256((tmp_path / rel).read_bytes()).hexdigest() == digest
