# Exact Archive Link Consent

## Scope

This private native candidate extends fresh historical one-plan archive-only approvals. It does not alter the live checker, consumer plans, captured prompts, signed records or actual archive state. The native minor/schema2 path and ordinary task/follow-on hashes retain their existing strict contracts.

Both historical one-plan specifications may include exactly this additional native-selector object: `"archive_link_relocation": {"moved_minor": "v2.12", "affected_plan": "docs/releases/v2/v2.13/plans/v2.13.0-adoption-craft-editors-embeddinggemma-2.md"}`. The only approval class permitted with this opt-in is one `archive-minor` entry. The existing actual-release/source-branch and migration-ratification fields remain required where their native contracts require them. The session must be explicit and real. Supplied hashes, variant arrays, preimages and extra nested selectors are refused.

## Frozen Consent

The native renderer derives one original full LF preimage and its sole alternate through the existing v2.12 move map. Exactly two link destinations may change, with zero mention changes and unchanged labels, tasks, prose, headings and checkboxes. Both fresh pages display the same full path, exact links, full-text/plan hashes, map hash and v2.12-before-v2.13 order. Their normal sealed page/capture/HMAC machinery freezes identical prospective consent. Existing records do not gain this scope automatically.

The central schema1 archive-only verifier accepts the exact original or alternate only at the unchanged active v2.13 plan path. It authenticates the record before trusting this metadata. All unsigned selectors and signed derived fields must replay exactly. A bad or missing HMAC, wrong scope/root/session, schema2/member/implementation class or malformed map cannot use the exception. Normal pause, blocker and completion state remains readable through the existing lifecycle path. The paired repair gate refuses paused, open-blocked or completed participants. Signed native answer receipts remain audit entries, with exact shape and an actual answered blocker; they do not add substantive advance authority. The general Context.plan_hash_matches function remains strict. At an archived path, only the ordinary newly refrozen own hash applies; the consent remains signed history, with no third variant.

## Native Archive Boundary

The v2.12 foreign-repair exception requires both canonical, unique, authenticated records from the same real owner session and repository, matching payloads, no live runner, exact record snapshots, and the exact original-to-alternate repair. Native projection covers all ledger and foreign plan/seed inputs through the complete repair preview, and requires the frozen foreign base migration/seed evidence to remain identical.

The actual transaction rechecks authority bytes and runner state before moving and before each repair. It repeats foreign-owner discovery and checks the actual foreign input/output, rather than relying on the earlier preview. Immediately before commit it verifies the actual repaired full foreign text, signed binding and current base proof dictionary again. It never writes, reseals, retires or completes the foreign record.

For this opted-in transaction, rollback restores a file only while its current bytes equal the native repaired preimage. Already-original files need no write. Later foreign bytes, including non-UTF8 partial content, remain preserved; independent restores and move reversal still run, and the result refuses with manual recovery required. No automatic git reset or recovery retry is introduced. This remains cooperative snapshot protection, not a filesystem fence against arbitrary concurrent writers ignoring the qualified archive protocol.

## Order

Before v2.12 moves, a successful current v2.13 dry run prints `CONDITIONAL ARCHIVE READY v2.13 required-before=v2.12`. It does not print an unconditional `WOULD ARCHIVE`. Actual v2.13 apply refuses while v2.12 remains active. Later actual apply requires the v2.12 source absent, the committed archive present, its archived authority verified, and the active v2.13 plan equal the exact approved alternate. A manual two-link edit alone does not prove the prerequisite archive.

The supported actual order is v2.12, then v2.13. The ordinary own archive/refreeze preserves the static consent. The requested consumer goal remains archive-readiness; all actual archives and associated deletions remain outside this private qualification.

## Qualification

The frozen source list is source-freeze.json and the baseline-relative patch is variant-source.diff. The maker runner qualify_frozen_variant.py retains exact commands, source hashes, logs and JUnit results. The unchanged fourteen one-plan-envelope/fixture cases are byte-identical to the previously qualified combined baseline. Native isolated CLI cases exercise genuine throwaway render/capture/create and ordered archive/refreeze, stale authorities, proof drift, changed actual inputs, new foreign owners and preservation of post-write external content. No production capture or record is used.

The retained consumer content projection uses the immutable c434 source archive and independently qualified final245+14/historical ledger mirrors, preserving their exact raw hashes, including legitimate mixed line endings. It derives the real two v2.13 links at lines55-56, proves unchanged foreign base evidence, and retains all eight v2.13 qualified proofs and forty-four v2.12 historical proofs. That content proof is not an approval, publication or actual archive receipt.

## Limits

Fresh historical owner approvals and native runtime adoption remain the parent agent's responsibility after actual carry/closure audit. No start-head inheritance, synthetic met task, arbitrary tag override, broad path normalization, foreign-record mutation transaction or new approval framework is provided. The first v1 in-flight aggregate overlapped proof/rollback fixes and is superseded; it is not final source-stable evidence. Frozen v2 broad compatibility remains separately identified, and v3 changes only lifecycle eligibility placement and native answer receipt handling. The final v3 qualification covers all opted-in boundaries, including the real blocker-answer lifecycle. construction-debt: one strict native-derived two-link pair, one archive-only verifier, existing evidence projection and transaction guards, fixed page display, and focused regressions.
