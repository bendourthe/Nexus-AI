from pathlib import Path
import copy,json
import pytest
from test_exact_link_variants import repo,pair,ck,cm,mc,PLAN,FOREIGN,V05,V06,SESSION,_isolated_git_config,_no_transport_overrides
from test_exact_link_order import command
from validators.test_gap_migration_and_archive import LINK_CHECKER


def preview(repo):
    rctx=repo.rctx()
    files=rctx._git_out('ls-files','-z').split('\0')
    tree=V05;dest=V05.replace('docs/releases/','docs/archives/')
    return mc.plan_repairs(repo.work,[(p,p,dest+p[len(tree):] if p.startswith(tree+'/') else p) for p in files if p],tree,dest)


def resign(record):
    record['approvals_hmac']=ck._sign(record,ck._secret(create=False))
    return record


def test_missing_ambiguous_or_foreign_consent_and_stale_snapshots_refuse(pair):
    repo,records,_=pair
    rctx=repo.rctx();repairs=preview(repo)
    ctx=ck.Context(str(repo.work/FOREIGN),ck.Budget(180));path=ctx.record_path();raw=path.read_bytes()
    own_ctx=ck.Context(str(repo.work/PLAN),ck.Budget(180));own_path=own_ctx.record_path();own_raw=own_path.read_bytes()
    original=repo.read(FOREIGN)
    accepted=mc.link_relocation_permit(rctx,records[PLAN],repairs,'v0.5',apply=False)
    assert accepted is not None and not mc.bound_plan_refusals(rctx,repairs,records[PLAN],accepted)
    assert mc.bound_plan_refusals(rctx,repairs,records[PLAN]),'ordinary archive-minor cannot bypass a live frozen plan'
    modifications=[lambda x:x.update(session_id='another-session'),lambda x:x.update(repo_root=str(repo.tmp)),
        lambda x:x.update(pause={'at':'paused'}),lambda x:x.update(completed={'at':'completed'}),
        lambda x:x.update(blockers=[{'open':True,'category':'owner'}]),
        lambda x:x['approvals'].update(classes=[{'class':'push-merge'}]),
        lambda x:x['approvals']['archive_evidence'].pop('link_relocation'),
        lambda x:x['approvals']['archive_evidence']['link_relocation'].update(map_sha256='not-native')]
    for change in modifications:
        changed=copy.deepcopy(records[FOREIGN]);change(changed);resign(changed);ck._write_record(path,changed)
        with pytest.raises((mc.Refused,ck.Malformed)):
            mc.link_relocation_permit(repo.rctx(),records[PLAN],repairs,'v0.5',apply=False)
        path.write_bytes(raw)
        assert repo.read(FOREIGN)==original and own_path.read_bytes()==own_raw
    changed=copy.deepcopy(records[FOREIGN]);changed['approvals_hmac']='0'*64;ck._write_record(path,changed)
    with pytest.raises(mc.Refused):mc.link_relocation_permit(repo.rctx(),records[PLAN],repairs,'v0.5',apply=False)
    path.write_bytes(raw)
    duplicate=path.with_name('duplicate-foreign.json');duplicate.write_bytes(raw)
    try:
        with pytest.raises(mc.Refused):mc.link_relocation_permit(repo.rctx(),records[PLAN],repairs,'v0.5',apply=False)
    finally:duplicate.unlink()
    runner=path.with_name(path.stem+'.runner.lock');runner.write_text('private fixture')
    try:
        with pytest.raises(mc.Refused):mc.link_relocation_permit(repo.rctx(),records[PLAN],repairs,'v0.5',apply=False)
    finally:runner.unlink()
    for target in (path,own_path):
        before=target.read_bytes();target.write_bytes(before+b' ')
        try:
            with pytest.raises(mc.Refused):mc._recheck_link_permit(accepted)
        finally:target.write_bytes(before)
    foreign=next(r for r in repairs if r.old_rel==FOREIGN)
    for wrong in [mc.replace(foreign,repaired=foreign.repaired+'changed prose\n'),mc.replace(foreign,mentions=1),mc.replace(foreign,links=3),mc.replace(foreign,new_rel=FOREIGN.replace('docs/releases/','docs/archives/'))]:
        assert not mc._exact_link_repair(wrong,accepted['payload'])
    repo.write(FOREIGN,foreign.repaired)
    try:
        with pytest.raises(mc.Refused):mc._recheck_link_permit(accepted,foreign,repo.work)
        with pytest.raises(mc.Refused):mc.link_relocation_permit(repo.rctx(),records[FOREIGN],[],'v0.6',apply=True)
    finally:repo.write(FOREIGN,original)
    assert path.read_bytes()==raw and own_path.read_bytes()==own_raw


@pytest.mark.parametrize('pair',['migration'],indirect=True)
def test_all_native_repairs_must_preserve_real_frozen_foreign_migration_proof(pair):
    repo,records,_=pair
    frozen=records[FOREIGN]['approvals']['archive_evidence']
    assert len(frozen['existing_migrations'])==1
    assert ck.load_record(ck.Context(str(repo.work/FOREIGN),ck.Budget(180)),SESSION).forced is None
    paths=[ck.Context(str(repo.work/p),ck.Budget(180)).record_path() for p in (PLAN,FOREIGN)]
    before={p:p.read_bytes() for p in paths}
    result=command(repo,'v0.5',PLAN)
    assert result.returncode==3 and 'foreign repair or frozen historical proofs differ' in result.stdout,result.stdout+result.stderr
    assert (repo.work/V05).is_dir() and not (repo.work/V05.replace('docs/releases/','docs/archives/')).exists()
    assert all(p.read_bytes()==raw for p,raw in before.items())


def test_stale_actual_foreign_file_rolls_back_move_without_overwriting_external_text(pair,monkeypatch):
    repo,records,_=pair
    repairs=preview(repo);permit=mc.link_relocation_permit(repo.rctx(),records[PLAN],repairs,'v0.5',apply=True)
    original=repo.read(FOREIGN);external=original+'\nExternal owner note.\n'
    real_move=mc.move_tree
    def move_then_external(*args):
        real_move(*args);repo.write(FOREIGN,external)
    monkeypatch.setattr(mc,'move_tree',move_then_external)
    with pytest.raises(mc.Refused,match='link-relocation-source-changed'):
        mc._apply_archive(repo.rctx(),'v0.5',V05,V05.replace('docs/releases/','docs/archives/'),repo.rctx()._git_out('ls-files','-z').split('\0'),LINK_CHECKER,permit)
    assert repo.read(FOREIGN)==external
    assert (repo.work/V05).is_dir() and not (repo.work/V05.replace('docs/releases/','docs/archives/')).exists()
