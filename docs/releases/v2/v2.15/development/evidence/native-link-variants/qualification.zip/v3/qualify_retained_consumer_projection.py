from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,tempfile
w=Path(__file__).resolve().parent
sys.path.insert(0,str(w/'scripts'))
import check_plan_completion as ck,completion_minor as cm,minor_close as mc
freeze=json.loads((w/'source-freeze.json').read_text())
if any(hashlib.sha256((w/'scripts'/n).read_bytes()).hexdigest()!=h for n,h in freeze['sha256'].items()):raise RuntimeError('candidate source drift')
out=Path(tempfile.mkdtemp(prefix='nexus-exact-variant-consumer-projection-'));root=out/'tree';root.mkdir()
archive=Path('C:/Users/bdour/AppData/Local/Temp/nexus-full-archive-projection-hu3p9zuj/source.tar')
with tarfile.open(archive) as source:
    for item in source:
        rel=item.name
        if not item.isfile() or not rel.startswith('docs/') or not (rel.endswith('/known-gaps.md') or ('/plans/' in rel and rel.endswith('.md'))):continue
        if '..' in Path(rel).parts:raise RuntimeError('unsafe retained archive member')
        target=root/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.extractfile(item).read())
qualification=Path('C:/Users/bdour/AppData/Local/Temp/nexus-independent-closure-qualification-wbupg_ve/qualification.json')
if hashlib.sha256(qualification.read_bytes()).hexdigest()!='4e1aaeb3f92f25ae9ade095abcb130339fde914f15efc353360e864dbc160a62':raise RuntimeError('retained final mirror qualification changed')
mirrors=[(qualification.parent/'mirror',json.loads(qualification.read_text())['final_ledger_hashes'])]
chain=Path('C:/Users/bdour/AppData/Local/Temp/nexus-independent-historical-chain-nb26ud1_')
mirrors.append((chain/'mirror',json.loads((chain/'applicable-contract-proof.json').read_text())['historical_extra_raw_sha256']))
for mirror,pins in mirrors:
    for rel,digest in pins.items():
        raw=(mirror/rel).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=digest:raise RuntimeError('retained raw ledger changed: '+rel)
        target=root/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
        if hashlib.sha256(target.read_bytes()).hexdigest()!=digest:raise RuntimeError('projection copy changed bytes')
def git(*args):
    r=subprocess.run(['git','-C',str(root),*args],capture_output=True,text=True)
    if r.returncode:raise RuntimeError(r.stderr)
    return r.stdout
git('init','-q');git('config','core.autocrlf','false');git('remote','add','origin','https://github.com/bendourthe/Nexus-AI.git');git('add','docs')
ctx=ck.RepoContext(root,ck.Budget(180))
foreign=cm.scan_plans(root,2,13)[-1];moved=cm.scan_plans(root,2,12)[-1]
fctx=ck.Context(str(root/foreign.rel),ctx.budget)
payload=mc._link_relocation_payload(ctx,'v2.12',foreign.rel,moved.rel,foreign.text)
base=cm.one_plan_archive_evidence(ck,fctx,ratify=False) or {'absorbed_plans':[],'ratify_existing_migrations':False,'existing_migrations':[]}
proof_record={'approvals':{'archive_evidence':{**base,'link_relocation':payload}}}
tree,dest=payload['source_tree'],payload['archive_tree'];files=[p for p in git('ls-files','-z').split('\0') if p]
repairs=mc.plan_repairs(root,[(p,p,dest+p[len(tree):] if p.startswith(tree+'/') else p) for p in files],tree,dest)
foreign_repair=next(r for r in repairs if r.old_rel==foreign.rel)
projected=mc._projected_foreign_evidence(ctx,payload,proof_record,repairs)
if not projected or not mc._exact_link_repair(foreign_repair,payload):raise RuntimeError('real retained foreign proof/map projection refused')
# Content-only ordered projection; no native approvals or run-record writes.
for rel in files:
    if rel.startswith(tree+'/'):
        target=root/(dest+rel[len(tree):]);target.parent.mkdir(parents=True,exist_ok=True);(root/rel).rename(target)
for repair in repairs:(root/repair.new_rel).write_bytes(repair.repaired.encode())
ledgers,unreadable=cm.load_ledgers(root)
if unreadable:raise RuntimeError('unreadable projected ledger')
source13=next(l for l in ledgers if l.minor==(2,13));source12=next(l for l in ledgers if l.minor==(2,12))
qualified13=[i for i in source13.items if i.state=='migrated'];proofs12=[i for i in source12.items if i.state=='migrated']
normal13=[cm.plan_migration_met(ledgers,source13,i) for i in qualified13]
full12=[cm.historical_archive_proof(ledgers,source12,i) is not None for i in proofs12]
if len(normal13)!=8 or not all(normal13) or len(full12)!=44 or not all(full12):raise RuntimeError('projected historical proof counts differ')
value={'scope':'PRIVATE retained final245+14 content projection; not actualarchive/authority/publication proof','source_archive':str(archive),'candidate_sha256':freeze['sha256'],'retained_raw_ledgers_verified':sum(len(p) for _,p in mirrors),'payload':payload,'foreign_base_before':base,'foreign_base_unchanged_after_all_native_repairs':projected,'foreign_exact_two_link_repair':True,'native_repair_files':len(repairs),'v13_qualified_normal_proofs':{'count':len(normal13),'all_pass':all(normal13)},'v12_full_historical_proofs':{'count':len(full12),'all_pass':all(full12)},'production_changes':False}
(out/'projection-proof.json').write_text(json.dumps(value,indent=2),encoding='utf-8')
print(json.dumps({'status':'PASS','output':str(out/'projection-proof.json'),'foreign_plan':foreign.rel,'links':payload['links'],'v13_proofs':len(normal13),'v12_proofs':len(full12)}))
