from pathlib import Path
import pytest
from validators.test_one_plan_archive_ratification import *

@pytest.fixture(autouse=True)
def private_original_archive_child_paths(monkeypatch):
    import validators.test_completion_minor_record as records
    import validators.test_gap_migration_and_archive as close
    scripts=Path(__file__).resolve().parent/'scripts'
    monkeypatch.setattr(records,'CHECKER',scripts/'check_plan_completion.py')
    monkeypatch.setattr(close,'CLOSE',scripts/'minor_close.py')
