"""Private throwaway repositories; no actual capture, record or archive mutation."""
from pathlib import Path
import copy
import json
import sys

import pytest

sys.path.insert(0, 'C:/nh-checker/tests')
import validators.test_completion_minor_record as base
import validators.test_gap_migration_and_archive as gaps
from validators.test_check_plan_completion import _git, _isolated_git_config
from validators.test_completion_minor_record import SESSION, _no_transport_overrides
from validators.test_gap_migration_and_archive import repo, ck, cm, mc, ledger, section, V05, V06, GAPS05, GAPS06
from validators.test_one_plan_archive_ratification import prepare, PLAN

HERE = Path(__file__).resolve().parent
FOREIGN = V06 + '/plans/v0.6.0-gamma.md'


@pytest.fixture
def pair(repo, monkeypatch, request):
    monkeypatch.setattr(base, 'CHECKER', HERE / 'scripts/check_plan_completion.py')
    monkeypatch.setattr(gaps, 'CLOSE', HERE / 'scripts/minor_close.py')
    prepare(repo)
    repo.write(GAPS05, ledger('v0.5', section('v0.5.10', 0, ''), status='finalized', open_items=0))
    repo.write(GAPS06, ledger('v0.6', section('v0.6.0', 0, ''), status='finalized', open_items=0))
    repo.write(FOREIGN, '# Plan gamma\n\n**Version**: v0.6.0\n**Slug**: gamma\n**Status**: complete\n\n'
               'Uses [alpha](../../v0.5/plans/v0.5.2-alpha.md) and [omega](../../v0.5/plans/v0.5.10-omega.md).\n\n'
               '## Phase 1\n\n- [x] T001 Build src/g.txt\n')
    repo.write('src/g.txt', 'complete fixture\n')
    if getattr(request, 'param', None) in {'migration','stable-migration'}:
        body='#### WN-3: Historical foreign proof\n\n- **Plan reference**: [alpha](../v0.5/plans/v0.5.2-alpha.md)\n- **Reason**: vendor API missing\n\n'
        if getattr(request, 'param', None) == 'stable-migration':
            body=body.replace('- **Plan reference**: [alpha](../v0.5/plans/v0.5.2-alpha.md)\n','')
        source_text=ledger('v0.6',section('v0.6.0',1,body),open_items=1)
        if getattr(request, 'param', None) == 'stable-migration':
            source_text=source_text.replace('## v0.6.0','[Prior](../v0.5/plans/v0.5.2-alpha.md)\n\n## v0.6.0',1)
        repo.write(GAPS06, source_text)
        ctx=repo.rctx()
        all_ledgers,_=cm.load_ledgers(repo.work)
        source=next(value for value in all_ledgers if value.rel==GAPS06)
        migration=mc._migration_texts(ctx,'v0.6#WN-3',source,source.items[0],'v0.8',mc._target_ledger(ctx,all_ledgers,'v0.8'),'vendor-feature','private full proof fixture','2026-10-21',ledgers=all_ledgers)
        mc.apply_migration(migration)
        repo.write(GAPS06,repo.read(GAPS06).replace('**Status**: in-progress','**Status**: finalized'))
    repo.commit('complete two historical fixture plans')
    anchor = repo.head()
    _git(repo.work, 'checkout', '-q', 'main')
    _git(repo.work, 'merge', '-q', '--ff-only', 'chore/close-v0.5')
    repo.integrate()
    _git(repo.work, 'checkout', '-q', 'chore/close-v0.5')
    repo.ship('v0.6.1')
    repo.state.setdefault('pr_by_branch', {})['feat/v0.6.0-gamma'] = {'state': 'MERGED', 'merge_commit': anchor}
    repo.save_state()
    records, pages = {}, {}
    for plan, branch in [(PLAN, 'feat/v0.5.10-omega'), (FOREIGN, 'feat/v0.6.0-gamma')]:
        spec = {'repo': 'acme/demo', 'source_branch': branch, 'target_branch': 'develop', 'tag': 'v0.6.1', 'release_version': 'v0.6.1',
                'classes': [{'class': 'archive-minor'}], 'archive_link_relocation': {'moved_minor': 'v0.5', 'affected_plan': FOREIGN}}
        if plan == FOREIGN and getattr(request, 'param', None) in {'migration','stable-migration'}:
            spec['ratify_existing_migrations'] = True
        path = repo.tmp / (Path(plan).stem + '-spec.json')
        path.write_text(json.dumps(spec), encoding='utf-8')
        repo.capture(SESSION, '/implement historical archive-only fixture', at=0.0)
        shown = repo.run('record', 'render', plan, '--session', SESSION, '--approvals', str(path), '--page')
        assert shown.returncode == 0, shown.stdout + shown.stderr
        rendered = repo.run('record', 'render', plan, '--session', SESSION, '--approvals', str(path))
        assert rendered.returncode == 0, rendered.stdout + rendered.stderr
        repo.capture(SESSION, rendered.stdout.splitlines()[0])
        created = repo.run('record', 'create', plan, '--session', SESSION, '--approvals', str(path))
        assert created.returncode == 0, created.stdout + created.stderr
        ctx = ck.Context(str(repo.work / plan), ck.Budget(180))
        state = ck.load_record(ctx, SESSION)
        assert state.forced is None and state.record is not None
        records[plan], pages[plan] = state.record, shown.stdout
    return repo, records, pages


@pytest.mark.parametrize('value', [None, [], {}, {'moved_minor': None, 'affected_plan': FOREIGN},
    {'moved_minor': 'v0.5', 'affected_plan': FOREIGN, 'hash': 'supplied'},
    {'moved_minor': 'v0.5', 'affected_plan': '../outside.md'},
    {'moved_minor': 'v0.5.1', 'affected_plan': FOREIGN}])
def test_bad_unsigned_selectors_are_malformed(value):
    with pytest.raises(ck.Malformed):
        cm.archive_link_selectors(ck, {'classes': [{'class': 'archive-minor'}], 'archive_link_relocation': value})


def test_opt_in_cannot_enter_schema2_or_implementation_classes():
    spec = {'classes': [{'class': 'archive-minor'}], 'archive_link_relocation': {'moved_minor': 'v0.5', 'affected_plan': FOREIGN}}
    with pytest.raises(ck.Malformed):
        cm.archive_link_selectors(ck, spec, minor=True)
    spec['classes'].append({'class': 'push-merge'})
    with pytest.raises(ck.Malformed):
        cm.archive_link_selectors(ck, spec)


def test_both_real_pages_freeze_identical_exact_variants_and_binding(pair):
    repo, records, pages = pair
    payload = records[FOREIGN]['approvals']['archive_evidence']['link_relocation']
    assert records[PLAN]['approvals']['archive_evidence']['link_relocation'] == payload
    assert len(payload['links']) == 2
    for page in pages.values():
        assert 'exactly two reference destinations' in page and 'v0.5 before v0.6' in page
        assert FOREIGN in page and payload['original_text_sha256'] in page and payload['relocated_text_sha256'] in page
        for link in payload['links']:
            assert link['old'] in page and link['new'] in page
    ctx = ck.Context(str(repo.work / FOREIGN), ck.Budget(180))
    record = records[FOREIGN]
    assert cm.schema1_archive_plan_binding(ck, ctx, record)
    original = repo.read(FOREIGN)
    repo.write(FOREIGN, mc.relocated_link_text(payload))
    moved = ck.Context(str(repo.work / FOREIGN), ck.Budget(180))
    assert not moved.plan_hash_matches(record['plan_sha256']), 'ordinary hashing must stay strict'
    assert ck.load_record(moved, SESSION).forced is None
    assert cm.schema1_archive_plan_binding(ck, moved, record)
    assert not mc.plan_refusals(repo.rctx(), 'v0.6', record), 'bound published source lineage still proves the alternate'
    for changed in [moved.text + '\nUnapproved prose.\n', moved.text.replace('[x] T001', '[ ] T001'),
                    moved.text.replace('[alpha]', '[different label]')]:
        repo.write(FOREIGN, changed)
        current = ck.Context(str(repo.work / FOREIGN), ck.Budget(180))
        assert not cm.schema1_archive_plan_binding(ck, current, record)
        assert ck.load_record(current, SESSION).forced == ck.TAMPERED
    repo.write(FOREIGN, original)
    for mutate in [lambda value: value.update(schema=2), lambda value: value.update(session_id='auto'),
                   lambda value: value['approvals']['classes'].append({'class': 'push-merge'}),
                   lambda value: value.update(repo_root=str(repo.tmp)),
                   lambda value: value['approvals']['archive_evidence']['link_relocation'].update(map_sha256='arbitrary')]:
        damaged = copy.deepcopy(record)
        mutate(damaged)
        damaged['approvals_hmac'] = ck._sign(damaged, ck._secret(create=False))
        assert not cm.schema1_archive_plan_binding(ck, ctx, damaged)
    bad = copy.deepcopy(record)
    bad['approvals_hmac'] = '0' * 64
    from unittest.mock import patch
    with patch.object(mc, 'valid_link_relocation_payload', side_effect=AssertionError('untrusted metadata accessed')):
        assert not cm.schema1_archive_plan_binding(ck, ctx, bad)
