from pathlib import Path
import copy,json
import pytest
from test_exact_link_variants import repo,pair,ck,cm,mc,PLAN,FOREIGN,V05,V06,SESSION,_isolated_git_config,_no_transport_overrides
from test_exact_link_negative import preview,resign


def test_derivation_is_only_two_links_and_foreign_release_still_needs_actual_source_ancestry(pair):
    repo,records,_=pair
    ctx=ck.Context(str(repo.work/FOREIGN),ck.Budget(180))
    payload=records[FOREIGN]['approvals']['archive_evidence']['link_relocation']
    original=payload['original_text']
    assert mc.valid_link_relocation_payload(ctx,payload)
    for changed in [original+'\n[third](../../v0.5/plans/v0.5.2-alpha.md)\n',original+'\n'+V05+'/plans/v0.5.2-alpha.md\n',original.replace('[x] T001','[ ] T001')]:
        with pytest.raises(ck.Malformed):mc._link_relocation_payload(ctx,'v0.5',FOREIGN,PLAN,changed)
    for changed in [{'original_text_sha256':'0'*64},{'links':payload['links'][:1]},{'repo_root':str(repo.tmp)},{'source_tree':'docs/v0/v0.5'}]:
        bad=copy.deepcopy(payload);bad.update(changed)
        assert not mc.valid_link_relocation_payload(ctx,bad)
    raw=ctx.record_path().read_bytes()
    damaged=copy.deepcopy(records[FOREIGN]);damaged['approvals']['tag']='v0.4.9';damaged['approvals']['release_version']='v0.4.9';resign(damaged)
    ck._write_record(ctx.record_path(),damaged)
    repo.write(FOREIGN,mc.relocated_link_text(payload))
    try:
        assert ck.load_record(ck.Context(str(repo.work/FOREIGN),ck.Budget(180)),SESSION).forced is None
        assert mc.plan_refusals(repo.rctx(),'v0.6',damaged),'published unrelated release cannot prove later source anchor'
    finally:ctx.record_path().write_bytes(raw);repo.write(FOREIGN,original)


def test_fresh_page_binds_foreign_text_before_capture_is_consumed(pair):
    repo,records,_=pair
    retired=repo.run('record','retire',PLAN,'--session',SESSION)
    assert retired.returncode==0,retired.stdout+retired.stderr
    spec=repo.tmp/(Path(PLAN).stem+'-spec.json')
    rendered=repo.run('record','render',PLAN,'--session',SESSION,'--approvals',str(spec))
    assert rendered.returncode==0,rendered.stdout+rendered.stderr
    repo.capture(SESSION,rendered.stdout.splitlines()[0])
    foreign_original=repo.read(FOREIGN)
    repo.write(FOREIGN,foreign_original+'\nChanged foreign scope before create.\n')
    result=repo.run('record','create',PLAN,'--session',SESSION,'--approvals',str(spec))
    assert result.returncode!=0,result.stdout+result.stderr
    assert 'approval' in result.stdout+result.stderr
    ctx=ck.Context(str(repo.work/PLAN),ck.Budget(180))
    assert not ctx.record_path().exists()
    assert repo.read(FOREIGN).endswith('Changed foreign scope before create.\n')


def test_new_foreign_owner_between_preview_and_write_refuses_and_rolls_back(pair,monkeypatch):
    repo,records,_=pair
    repairs=preview(repo);permit=mc.link_relocation_permit(repo.rctx(),records[PLAN],repairs,'v0.5',apply=True)
    ctx=ck.Context(str(repo.work/FOREIGN),ck.Budget(180));raw=ctx.record_path().read_bytes()
    duplicate=ctx.record_path().with_name('new-foreign-owner.json')
    real_move=mc.move_tree
    def move_then_owner(*args):
        real_move(*args);duplicate.write_bytes(raw)
    monkeypatch.setattr(mc,'move_tree',move_then_owner)
    from validators.test_gap_migration_and_archive import LINK_CHECKER
    with pytest.raises(mc.Refused,match='plan-bound-by-another-run'):
        mc._apply_archive(repo.rctx(),'v0.5',V05,V05.replace('docs/releases/','docs/archives/'),repo.rctx()._git_out('ls-files','-z').split('\0'),LINK_CHECKER,permit)
    assert (repo.work/V05).is_dir()
    assert repo.read(FOREIGN)==records[FOREIGN]['approvals']['archive_evidence']['link_relocation']['original_text']
    assert duplicate.read_bytes()==raw
