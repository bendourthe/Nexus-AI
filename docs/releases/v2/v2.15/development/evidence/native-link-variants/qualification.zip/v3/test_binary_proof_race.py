import pytest
from test_exact_link_variants import repo,pair,ck,mc,PLAN,FOREIGN,V05,GAPS06,_isolated_git_config,_no_transport_overrides
from test_exact_link_negative import preview
from test_post_repair_proof_races import apply,frozen_records

@pytest.mark.parametrize('pair',['stable-migration'],indirect=True)
def test_external_non_utf8_proof_bytes_are_preserved_and_moves_are_undone(pair,monkeypatch):
    repo,records,_=pair
    permit=mc.link_relocation_permit(repo.rctx(),records[PLAN],preview(repo),'v0.5',apply=True)
    original=repo.read(FOREIGN);before_head=repo.head();before_records=frozen_records(repo)
    real_write=mc._write_atomic;target=repo.work/GAPS06;external=b'\xffEXTERNAL_PARTIAL_WRITE\x80';changed=[]
    def write_then_binary(path,text):
        real_write(path,text)
        if path==target and not changed:
            changed.append(True);target.write_bytes(external)
    monkeypatch.setattr(mc,'_write_atomic',write_then_binary)
    with pytest.raises(mc.Refused,match='rollback-failed'):apply(repo,permit)
    assert changed and target.read_bytes()==external
    assert repo.read(FOREIGN)==original and repo.head()==before_head
    assert (repo.work/V05).is_dir()
    assert all(path.read_bytes()==raw for path,raw in before_records.items())
