# Exact Link Variant Qualification

## Completed

A NEW private native candidate supports two fresh historical schema1 archive-only pages with identical native-derived consent for exactly two v2.12 link relocations in the active v2.13 plan. The full LF original preimage and sole repaired variant, exact href map, plan/full-text hashes, repository identity and order are signed. Neither supplied hashes nor additional operative classes can enter the unsigned interface. Four modules changed relative to the already qualified combined prerequisite snapshot: check_plan_completion.py, completion_minor.py, minor_close.py and approval_page.py. Other three sibling modules are byte-identical.

The foreign guard requires both current, unique, same-session archive-only authorities and exact snapshots, no live runner, exact native repair and unchanged foreign historical evidence after complete proof-input projection. Immediately before commit it repeats actual full-text/binding/proof and authority checks. It never writes the foreign record. Opted-in rollback preserves external third-preimage bytes, including non-UTF8 partial content, continues independent restores/move reversal, and refuses manual recovery when complete restoration is unsafe.

Normal PAUSED, BLOCKED and completed loads retain their existing lifecycle behavior. The relocation gate refuses inactive participants. A genuine native answer receipt remains lifecycle audit metadata with exact shape and an answered blocker binding; extra substantive classes remain refused. The general hash/task/signing/follow-on functions stay unchanged.

## Verified

- Frozen v2 broad maker qualification: 52/52 PASS, 841.297 seconds, exact before/after source hashes. Independent same52: PASS839.46 seconds. Includes unchanged fourteen strict one-plan-envelope/fixture cases and original historical archive regressions.
- Final v3 maker qualification: 20/20 PASS248.25 seconds, exact before/after all7 source hashes. Independent same20: PASS244.47 seconds. The v3-only CM/MC diff changes lifecycle eligibility placement and native answer receipt handling; every opted-in branch is rerun.
- Real isolated native render/capture/create and ordered apply/refreeze prove current foreign dryrun CONDITIONAL, foreign-first actual refusal, v2.12-style move with foreign record RAW bytes unchanged, and later own archive/refreeze with consent retained as history. No production capture or archive occurred.
- Real stale-record/new-owner/file/proof races refuse. An untouched proof input edited after preview is preserved. A source proof input edited after its native write is preserved with rollback-failed/manual recovery. Non-UTF8 external bytes are preserved and moves are still undone.
- Genuine native block/render/capture/answer/load proves BLOCKED remains actionable, valid signed lifecycle state is not labeled tampered, and answering does not grant additional operative authority.
- Retained final245+14/historical content projection derives the actual v2.13 href changes at lines55-56, preserves the foreign base proof dictionary, and keeps all8 v2.13 qualified and44 v2.12 historical full proofs valid. This uses immutable source/private independently qualified raw ledger mirrors, including legitimate mixed line endings, rather than changing actual ledgers.
- Final independent findings: []. Its receipt SHA256 is819758729d618e6a77b124e68dec5943df738c406f3db625a5c546d558055f69. Original14 bytes retained and9 core hash/task/signing/follow-on functions independently unchanged from combined0yx.

## Native Inputs

Both fresh one-plan specifications add exactly `"archive_link_relocation": {"moved_minor": "v2.12", "affected_plan": "docs/releases/v2/v2.13/plans/v2.13.0-adoption-craft-editors-embeddinggemma-2.md"}` and retain only the one substantive `archive-minor` class. Keep each independently proven source branch and actual published tag/release mapping. Use the existing v2.12 migration ratification opt-in for its44 current exact proofs. No actual authority or new spec was created by this qualification. Existing records do not auto-acquire consent, and a fresh record starts at the current HEAD without inheritance or backdating.

After source adoption and after final dispositions, the parent renders each real one-plan page with `record render <canonical-plan> --session <real-owner-session> --approvals <fresh-spec> --page`, then renders its paste using the same arguments without `--page`. Creation remains `record create <canonical-plan> --session <real-owner-session> --approvals <fresh-spec>` after genuine capture. When the hook captured the whole strict IDE wrapper, the existing qualified create-only `--approval-transcript <genuine-runtime-transcript>` adapter applies; no fake capture, journal insertion or record editing is authorized. The full frozen prospective payload must be identical on both pages.

The canonical moved plan is `docs/releases/v2/v2.12/plans/v2.12.0-outline-promotion-readiness.md`. The foreign plan is `docs/releases/v2/v2.13/plans/v2.13.0-adoption-craft-editors-embeddinggemma-2.md`. Native readiness probes use `minor_close.py archive --minor v2.12 --plan <moved-plan> --session <owner> --closing-branch <current-approved-closing-branch> --repo C:/nx-close --dry-run`, and similarly v2.13/foreign-plan. Current v2.13 success is explicitly `CONDITIONAL ARCHIVE READY v2.13 required-before=v2.12`; it must never be reported as unqualified simultaneous readiness. The actual supported order is v2.12 before v2.13. Manual href edits alone do not prove that prerequisite archive.

## Open

Actual native adoption, two fresh historical approval rounds and final current consumer readiness checks belong to the parent after actual245+14 audit. This candidate performs no actual archive, deletion, record/capture mutation, installation, commit or push. It adds no approval framework, foreign resealing transaction, inherited start head, task waiver, arbitrary tag or broad normalization. The existing own-record post-commit/refreeze lifecycle remains its existing contract; cooperative snapshots do not fence arbitrary writers ignoring the archive protocol. The first v1 aggregate overlapped review fixes and is explicitly superseded, not final source-stable evidence.

## Next

Use source-freeze.json and variant-source.diff for guarded adoption of the four changed modules after the protected actual run audit. Keep v3-lifecycle-only.diff with the separately retained frozen-v2 broad proof. The static packet contains source/tests/reports only and requires the existing native test harness for reproduction; it excludes runtime records, HMAC keys, captured prompts/transcripts, credentials and dependencies. The parent may copy the packet into durable release evidence after its actual-state audit. construction-debt: one native-derived pair, one archive-only binding path, bounded proof/repair/rollback checks and existing lifecycle handling.
