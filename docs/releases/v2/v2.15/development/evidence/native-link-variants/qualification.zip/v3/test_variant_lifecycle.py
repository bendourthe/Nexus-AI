import copy,json
import pytest
from test_exact_link_variants import repo,pair,ck,mc,cm,PLAN,FOREIGN,SESSION,_isolated_git_config,_no_transport_overrides
from test_exact_link_negative import preview,resign


def test_signed_lifecycle_states_load_honestly_and_native_block_answer_retains_archive_scope(pair):
    repo,records,_=pair
    ctx=ck.Context(str(repo.work/FOREIGN),ck.Budget(180));path=ctx.record_path();raw=path.read_bytes()
    mutations=[({'pause':{'at':ck._now()}},'PAUSED'),({'blockers':[{'open':True,'category':'no-progress'}]},'BLOCKED: no-progress'),({'completed':{'at':ck._now(),'head':repo.head()}},None)]
    for change,verdict in mutations:
        altered=copy.deepcopy(records[FOREIGN]);altered.update(change);resign(altered);ck._write_record(path,altered)
        loaded=ck.load_record(ck.Context(str(repo.work/FOREIGN),ck.Budget(180)),SESSION)
        assert loaded.record is not None
        assert (loaded.forced[0] if loaded.forced else None)==verdict
        assert cm.schema1_archive_plan_binding(ck,ctx,altered)
        with pytest.raises(mc.Refused):mc.link_relocation_permit(repo.rctx(),records[PLAN],preview(repo),'v0.5',apply=False)
        path.write_bytes(raw)
    blocked=repo.run('record','block',FOREIGN,'--session',SESSION,'--category','no-progress','--evidence','private lifecycle fixture')
    assert blocked.returncode==3 and blocked.stdout.strip()=='BLOCKED: no-progress',blocked.stdout+blocked.stderr
    loaded=ck.load_record(ck.Context(str(repo.work/FOREIGN),ck.Budget(180)),SESSION)
    assert loaded.forced[0]=='BLOCKED: no-progress'
    rendered=repo.run('record','render',FOREIGN,'--session',SESSION,'--action','answer','--blocker','0')
    assert rendered.returncode==0,rendered.stdout+rendered.stderr
    line=rendered.stdout.splitlines()[0];repo.capture(SESSION,line)
    answered=repo.run('record','answer',FOREIGN,'--session',SESSION,'--blocker','0','--text',line)
    assert answered.returncode==0 and 'ANSWERED blocker 0' in answered.stdout,answered.stdout+answered.stderr
    loaded=ck.load_record(ck.Context(str(repo.work/FOREIGN),ck.Budget(180)),SESSION)
    assert loaded.forced is None and loaded.record is not None
    assert loaded.record['blockers'][0]['open'] is False
    assert [c['class'] for c in loaded.record['approvals']['classes']]==['archive-minor','answer']
    assert mc.link_relocation_permit(repo.rctx(),records[PLAN],preview(repo),'v0.5',apply=False) is not None
    for extra in [{'class':'push-merge'},{'class':'answer'},{'class':'answer','blocker':999,'text':'not a native receipt'}]:
        bad=copy.deepcopy(loaded.record);bad['approvals']['classes'].append(extra);resign(bad)
        assert not cm.schema1_archive_plan_binding(ck,ctx,bad)
