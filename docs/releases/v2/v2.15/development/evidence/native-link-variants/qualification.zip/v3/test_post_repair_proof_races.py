import pytest
from test_exact_link_variants import repo,pair,ck,cm,mc,PLAN,FOREIGN,V05,GAPS06,SESSION,_isolated_git_config,_no_transport_overrides
from test_exact_link_negative import preview
from validators.test_gap_migration_and_archive import LINK_CHECKER


def apply(repo,permit):
    return mc._apply_archive(repo.rctx(),'v0.5',V05,V05.replace('docs/releases/','docs/archives/'),repo.rctx()._git_out('ls-files','-z').split('\0'),LINK_CHECKER,permit)


def frozen_records(repo):
    return {ck.Context(str(repo.work/p),ck.Budget(180)).record_path():ck.Context(str(repo.work/p),ck.Budget(180)).record_path().read_bytes() for p in (PLAN,FOREIGN)}


@pytest.mark.parametrize('pair',['stable-migration'],indirect=True)
def test_post_preview_untouched_proof_input_drift_refuses_before_commit_preserving_external_bytes(pair,monkeypatch):
    repo,records,_=pair
    original=repo.read(FOREIGN);permit=mc.link_relocation_permit(repo.rctx(),records[PLAN],preview(repo),'v0.5',apply=True)
    target=repo.work/'docs/releases/v0/v0.8/known-gaps.md'
    external=target.read_bytes().replace(b'vendor API missing',b'external vendor fact')
    before_head=repo.head();before_records=frozen_records(repo);real_move=mc.move_tree
    def move_then_change(*args):
        real_move(*args);target.write_bytes(external)
    monkeypatch.setattr(mc,'move_tree',move_then_change)
    with pytest.raises(mc.Refused,match='link-relocation-proof-changed'):apply(repo,permit)
    assert target.read_bytes()==external
    assert repo.read(FOREIGN)==original and repo.head()==before_head
    assert (repo.work/V05).is_dir()
    assert all(path.read_bytes()==raw for path,raw in before_records.items())


@pytest.mark.parametrize('pair',['stable-migration'],indirect=True)
def test_post_write_proof_input_external_bytes_survive_failed_rollback_without_success(pair,monkeypatch):
    repo,records,_=pair
    original=repo.read(FOREIGN);permit=mc.link_relocation_permit(repo.rctx(),records[PLAN],preview(repo),'v0.5',apply=True)
    before_head=repo.head();before_records=frozen_records(repo);real_write=mc._write_atomic
    target=repo.work/GAPS06;external=[]
    def write_then_external(path,text):
        real_write(path,text)
        if path==target and not external:
            changed=target.read_bytes().replace(b'vendor API missing',b'external owner proof note')
            external.append(changed);target.write_bytes(changed)
    monkeypatch.setattr(mc,'_write_atomic',write_then_external)
    with pytest.raises(mc.Refused,match='rollback-failed'):apply(repo,permit)
    assert external and target.read_bytes()==external[0]
    assert repo.read(FOREIGN)==original and repo.head()==before_head
    assert (repo.work/V05).is_dir()
    assert all(path.read_bytes()==raw for path,raw in before_records.items())
