"""Independent read-only actual-state check; run only after 245 carries and 14 closures finish."""
import argparse,datetime,hashlib,json,pathlib,re,sys,importlib.util,subprocess
sys.dont_write_bytecode=True
P=pathlib.Path(__file__).resolve().parent

def sha(b):return hashlib.sha256(b).hexdigest()
def check(ok,why):
 if not ok:raise ValueError(why)
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--after-closures',action='store_true',required=True);args=parser.parse_args()
 b=json.loads((P/'baseline.json').read_bytes());r=pathlib.Path(b['root']);q=pathlib.Path(b['qualification']);check(not P.is_relative_to(r),'private audit output must be outside repository');check(sha((q/'qualification.json').read_bytes())==b['qualification_sha256'],'private qualification changed');proof=json.loads((q/'qualification.json').read_bytes());check(proof['status']=='PASS' and proof['closures']==14 and proof['open_copies']==245,'private qualification incomplete')
 manifest_path=r/'docs/releases/v2/v2.15/development/v2.15.4-carry-forward-manifest.json';manifest_raw=manifest_path.read_bytes();check(sha(manifest_raw)==proof['manifest_sha256'],'frozen manifest changed');m=json.loads(manifest_raw)
 check(sha((r/'.nexus-hub/apply-carry-forward-manifest.py').read_bytes())==b['helper_sha256'],'execution helper changed')
 check(len(m['inputs'])==18,'frozen input denominator changed')
 for i in m['inputs']:check(sha((r/i['path']).read_bytes())==i['sha256'],'frozen input changed: '+i['path'])
 for name,wanted in proof['native_sha256'].items():
  check(sha((pathlib.Path('C:/nh-checker/scripts')/name).read_bytes())==wanted,'actual runtime changed: '+name);check(sha((q/'native'/name).read_bytes())==wanted,'private runtime changed: '+name)
 journal_path=pathlib.Path('C:/Users/bdour/AppData/Local/Temp/nexus-v215-carry-20261021-375a11466cff/completed-prefix-journal.json');journal_raw=journal_path.read_bytes();j=json.loads(journal_raw);check(j['status']=='COMPLETE_CARRIES_ONLY' and len(j['completed'])==245 and j['pending'] is None,'actual carries not complete')
 carry_entries=[e for e in m['entries'] if e['destination']];check([e['source_key'] for e in carry_entries]==[e['source_key'] for e in j['completed']],'completed carry order/set changed');amend=j['execution_amendment'];date=amend['execution_date'];check(date=='2026-10-21' and amend['proposal_date']=='2026-10-20' and amend['frozen_manifest_sha256']==proof['manifest_sha256'],'date amendment differs from qualified invocation');check(amend['runtime_sha256']==proof['native_sha256'] and amend['helper_sha256']==b['helper_sha256'],'journal runtime/helper binding differs');check(amend['time_basis']=='host-local calendar captured at invocation','date time basis differs');check(datetime.datetime.fromisoformat(j['started_at']).astimezone().date().isoformat()==date,'journal start local date does not corroborate execution date')
 actual={rel:(r/rel).read_bytes() for rel in proof['final_ledger_hashes']};check(len(actual)==11,'expected ten sources plus one target')
 for rel,raw in actual.items():check(sha(raw)==proof['final_ledger_hashes'][rel],'actual closure/carry final bytes differ: '+rel);check(raw==(q/'mirror'/rel).read_bytes(),'qualified private bytes changed: '+rel)
 s=importlib.util.spec_from_file_location('private_actual_helper',r/'.nexus-hub/apply-carry-forward-manifest.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);n=h.native_modules(q/'native',proof['native_sha256']);ledgers,unreadable=n.cm.load_ledgers(r);check(not unreadable,'unreadable actual ledger');by={l.rel:l for l in ledgers};check(sum(l.minor==(2,16) for l in ledgers)==1,'ambiguous actual destination ledger')
 for rel in actual:check(rel in by and not by[rel].problems,'actual parser problems: '+rel);check(by[rel].text.encode()==actual[rel],'actual ledger changed during audit: '+rel)
 targets=by[h.TARGET].items;check(len(targets)==245,'unexpected destination item count');results=[];seen=set();counts={'carry':0,'closure':0,'already-resolved':0}
 for e in m['entries']:
  key=e['source_key'];check(key not in seen,'duplicate original identity');seen.add(key);source=by[e['current']['ledger']];items=n.cm.gap_items(source.items,key);check(len(items)==1,'actual source ambiguous: '+key);item=items[0];d=e['destination']
  if d:
   check(item.state=='migrated' and item.body.startswith(e['current']['body']),'actual migration changed original body: '+key);check(re.fullmatch(r'(?:NI|DF|BG|WN|MT|QG)-[1-9][0-9]*',d['id']) is not None,'destination ID not numeric');found=n.cm.gap_items(targets,d['key']);check(len(found)==1 and found[0].state=='open','destination not exactly one open item: '+key);dest=found[0];check(dest.gid+dest.title==d['title'] and dest.body.startswith(d['copied_body']),'destination title/copied body changed: '+key);check(sha(d['copied_body'].encode())==d['copied_body_sha256_utf8'],'frozen copied body hash mismatch');suffix=dest.body[len(d['copied_body']):];suffix=suffix[2:] if suffix.startswith('\r\n') else suffix[1:] if suffix.startswith('\n') else suffix;check(suffix.startswith('- **Migrated from**: '+key+' on '+date+' (reason: user-deferred)'),'latest appended migration provenance differs: '+key);status,_=n.cm.migration_copy_status(ledgers,'v2.16.0',source,item,label=key,require_reason=True);check(status=='migration-copy-complete','native copy proof failed: '+key+' '+status);counts['carry']+=1;results.append({'source_key':key,'disposition':'migrated','destination':d['key'],'native_proof':status})
  elif e['disposition']=='already-resolved':
   check(item.state=='resolved' and item.gid+item.title==e['current']['title'] and item.body==e['current']['body'],'already-resolved item changed: '+key);counts['already-resolved']+=1;results.append({'source_key':key,'disposition':'already-resolved-unchanged'})
  else:
   check(item.state=='resolved' and item.body.startswith(e['current']['body']),'closure state/body differs: '+key);counts['closure']+=1;results.append({'source_key':key,'disposition':'resolved-narrow-evidence'})
 check(len(seen)==262 and counts=={'carry':245,'closure':14,'already-resolved':3},'262 identity partition differs')
 untouched=0;prefixes=0
 targeted={(e['current']['ledger'],e['source_key']) for e in m['entries'] if e['destination'] or e['disposition']!='already-resolved'}
 for source in m['source_files']:
  raw=subprocess.check_output(['git','-C',str(r),'show',proof['base']+':'+source['path']]);raw=raw if sha(raw)==source['sha256'] else raw.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n');check(sha(raw)==source['sha256'],'cannot reconstruct original exact bytes');old,issues=n.cm.parse_ledger_full(raw.decode());check(not issues,'baseline parser problem');current=by[source['path']];check(len(old)==len(current.items),'unaccounted source item count changed')
  for item in old:
   key=n.cm.section_version(item.section)+'#'+item.gid;found=n.cm.gap_items(current.items,key);check(len(found)==1,'original item no longer unique');new=found[0]
   if (source['path'],key) in targeted:check(new.body.startswith(item.body),'original source prefix changed: '+key);prefixes+=1
   else:check((new.title,new.body,new.state)==(item.title,item.body,item.state),'untargeted original changed: '+key);untouched+=1
 check(untouched==111 and prefixes==259,'original item preservation count differs')
 capture_drift=[name for name,wanted in b['captures'].items() if not (r/name).is_file() or sha((r/name).read_bytes())!=wanted];check(not capture_drift,'raw capture changed after preparation: '+str(capture_drift))
 for rel,raw in actual.items():check((r/rel).read_bytes()==raw,'actual ledger changed during audit: '+rel)
 check(manifest_path.read_bytes()==manifest_raw and journal_path.read_bytes()==journal_raw,'manifest/journal changed during audit')
 for i in m['inputs']:check(sha((r/i['path']).read_bytes())==i['sha256'],'frozen input changed during audit: '+i['path'])
 for name,wanted in proof['native_sha256'].items():check(sha((pathlib.Path('C:/nh-checker/scripts')/name).read_bytes())==wanted,'runtime changed during audit: '+name)
 result={'status':'PASS','authority':'independent read-only actual data audit; no publication/archive approval','recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':sha(manifest_raw),'journal_sha256':sha(journal_raw),'execution_date':date,'counts':counts,'original_identities':262,'actual_ledgers':11,'parser_problems_in_those_11':0,'untargeted_unchanged_including_three_already_resolved':111,'targeted_original_body_prefixes':259,'frozen_inputs':18,'native_modules':6,'raw_capture_files':len(b['captures']),'raw_capture_comparison_start_utc':b['recorded_at_utc'],'raw_capture_scope':b['raw_capture_scope'],'actual_ledger_sha256':{rel:sha(raw) for rel,raw in actual.items()},'results':results};(P/'actual-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('results','actual_ledger_sha256')},indent=2));print('Private report: '+str(P/'actual-audit.json'))
if __name__=='__main__':
 try:main()
 except Exception as error:
  print(json.dumps({'status':'FAIL','error':type(error).__name__+': '+str(error)}));sys.exit(1)
