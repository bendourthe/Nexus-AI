"""Prove the stopped 203-item prefix; continue it only after explicit review."""
from __future__ import annotations

import argparse
import copy
import datetime
import hashlib
import json
import os
import re
from pathlib import Path
import subprocess
import sys
import tempfile
import time
from types import ModuleType, SimpleNamespace

sys.dont_write_bytecode = True
ROOT = Path("C:/nx-close")
HUB = Path("C:/nh-checker/scripts")
ORIGINAL = ROOT / ".nexus-hub/apply-carry-forward-manifest.py"
ORIGINAL_SHA = "bb37d90e74488bff80d24b3328460b37f486116dbdcce1d3ba1c50764202db51"
JOURNAL = Path("C:/Users/bdour/AppData/Local/Temp/nexus-v215-carry-20261021-375a11466cff/completed-prefix-journal.json")
REVIEW = Path("C:/Users/bdour/AppData/Local/Temp/nexus-independent-prefix203-o9ubsh3o/prefix-proof.json")
STOP_SHA = "6e0dd98dafce126f760108ec20f14ac8930e1560e49a9e44c82a312de02d0075"
REVIEW_SHA = "cf74b7096d6cbb5b648cd120f4ed44053af5c346cf829d2fa81fa10d6327e636"
BASE = "c43432f04facf3540f20df537d722d973779860b"
PREFIX = 203
DATE = "2026-10-21"
PRIOR_LEASE = JOURNAL.with_name(JOURNAL.name + ".reviewed-prefix177-continuation.lock")
PRIOR_LEASE_SHA = "9d078eb3cd00db54709df7a028dd62f96f588864d0c3cd7f305e7ddf0d25e6cb"
PRIOR_HELPER_SHA = "3ba8dfc95af89302ae2bc19a41151482ec22000aa0ddb5ecd0270266a92d9eb5"
PRIOR_STOP_SHA = "a6ec7fc19bddc8fdf96389ece39e9bec73c3a21a97352be9025e74260b0b1fdc"
PRIOR_REVIEW_SHA = "392e2c9ed2787b582d4fd567f1de29891afe440d5ba4a252828d5ae16b09aaab"
PRIOR_STOP = Path("C:/Users/bdour/AppData/Local/Temp/nexus-prefix177-actual-20261021-2016-912ce7/stopped-prefix177-journal.raw.json")
OLDER_LEASE = JOURNAL.with_name(JOURNAL.name + ".reviewed-continuation.lock")
OLDER_LEASE_SHA = "33f5c28e577a574d7f3b8fa58626c05fc62926e4a9262262ddeda96171350083"
OLDER_STOP = Path("C:/Users/bdour/AppData/Local/Temp/nexus-prefix166-actual-20261021-1934-8e3691/stopped-prefix166-journal.raw.json")
OLDER_STOP_SHA = "3593e7e451d20133372fd4b364f8baf9fd937e2d95de12ad0cdef84c83aaf1c7"
OLDER_REVIEW_SHA = "4aad8ed3eb99638af90d83c02d83b5e5123e309def8d777433d2a028257f163a"
OLDER_HELPER_SHA = "9823af864cfabfd4fcc8608b8df2c95d571dfdbfa897063cb865bf4f44bce015"
CANONICAL_GUARD = Path("C:/nh-checker/catalog/skills/workflow/user-edit-preservation/scripts/edit_guard.py")
CANONICAL_GUARD_SHA = "e950fdbc10cdcf0853c0eb878d8c9345d0ebdbcb61a62f787fbd5cd5aecf22af"
GUARD_QUALIFICATION = Path("C:/Users/bdour/AppData/Local/Temp/nexus-independent-guard203-20261021-a7c9/qualification-final.json")
GUARD_QUALIFICATION_SHA = "f47f5a8e002e26588e703e2581e39fff10a3421903a20c1e0bfc93aaefd5e7d7"



def sha(raw):
    return hashlib.sha256(raw.encode() if isinstance(raw, str) else raw).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def pid_is_running(pid):
    """Query only; os.kill on Windows is intentionally never used."""
    require(os.name == "nt" and isinstance(pid, int) and pid > 0, "prior PID query unavailable")
    import ctypes
    from ctypes import wintypes
    api = ctypes.WinDLL("kernel32", use_last_error=True)
    api.OpenProcess.argtypes, api.OpenProcess.restype = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD], wintypes.HANDLE
    api.GetExitCodeProcess.argtypes, api.GetExitCodeProcess.restype = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)], wintypes.BOOL
    api.CloseHandle.argtypes, api.CloseHandle.restype = [wintypes.HANDLE], wintypes.BOOL
    handle = api.OpenProcess(0x1000, False, pid)
    if not handle:
        error = ctypes.get_last_error()
        require(error == 87, "prior PID status unknown: Win32 error " + str(error))
        return False
    try:
        code = wintypes.DWORD()
        require(bool(api.GetExitCodeProcess(handle, ctypes.byref(code))), "prior PID exit-code query failed")
        return code.value == 259
    finally:
        api.CloseHandle(handle)


def validate_prior_lease(raw, session, nonce, digest=PRIOR_LEASE_SHA):
    require(sha(raw) == digest, "retained prior lease changed")
    lease = json.loads(raw)
    require(lease.get("pid") == 31124 and lease.get("helper_sha256") == PRIOR_HELPER_SHA
            and lease.get("stopped_journal_sha256") == PRIOR_STOP_SHA and lease.get("prefix_review_sha256") == PRIOR_REVIEW_SHA
            and lease.get("session") == session and lease.get("nonce") == nonce and lease.get("execution_date") == DATE,
            "retained prior invocation identity differs")
    require(not pid_is_running(lease["pid"]), "prior invocation PID is still active")
    return lease


def validate_older_lease(raw, session, nonce, digest=OLDER_LEASE_SHA):
    require(sha(raw) == digest, "retained older166 lease changed")
    lease = json.loads(raw)
    require(lease.get("pid") == 9824 and lease.get("helper_sha256") == OLDER_HELPER_SHA
            and lease.get("stopped_journal_sha256") == OLDER_STOP_SHA and lease.get("prefix_review_sha256") == OLDER_REVIEW_SHA
            and lease.get("session") == session and lease.get("nonce") == nonce and lease.get("execution_date") == DATE,
            "retained older166 invocation identity differs")
    require(not pid_is_running(lease["pid"]), "older166 invocation PID is still active")
    return lease


def install_observers(h, output, native=None):
    """Preserve original return/raise behavior; retain failure details separately."""
    counter = 0
    def safe_text(value):
        value = re.sub(r"(?i)(?:https?|ssh)://\S+", "<url-redacted>", str(value))
        value = re.sub(r"(?i)\b(authorization|password|token|secret|api[_-]?key|hmac[_-]?key)\s*[:=]\s*\S+", r"\1=<redacted>", value)
        return re.sub(r"[A-Za-z0-9_+=./-]{32,}", "<long-value-redacted>", value)[-4000:]
    def safe_value(value):
        if isinstance(value, (bytes, bytearray)):
            return safe_text(value.decode("utf-8", errors="replace"))
        if isinstance(value, str):
            return safe_text(value)
        if isinstance(value, dict):
            return {key: safe_value(item) for key, item in value.items()}
        if isinstance(value, (tuple, list)):
            return [safe_value(item) for item in value]
        return value
    def diagnostic(value):
        nonlocal counter
        counter += 1
        value["at_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        try:
            with (output / ("failure-diagnostic-%03d.json" % counter)).open("xb") as stream:
                stream.write((json.dumps(safe_value(value), ensure_ascii=True, indent=2, default=str) + "\n").encode())
        except Exception as error:
            print("diagnostic persistence failed: " + type(error).__name__, file=sys.stderr)
    original_authority = h.authority
    def observed_authority(native, root, manifest, session, nonce):
        detail = {"kind": "authority", "load_returned": False}
        started = time.monotonic()
        def load(*args, **kwargs):
            context = args[1] if len(args) > 1 else None
            budget = getattr(context, "budget", None)
            if budget is not None:
                detail["budget_remaining_before"] = budget.remaining()
            result = native.cm.load_minor(*args, **kwargs)
            detail.update(load_returned=True, forced=result.forced, notices=getattr(result, "notices", None), record_present=result.record is not None)
            if budget is not None:
                detail["budget_remaining_after"] = budget.remaining()
            return result
        class PortProxy:
            def __init__(self, original, **overrides):
                self.original, self.overrides = original, overrides
            def __getattr__(self, name):
                return self.overrides[name] if name in self.overrides else getattr(self.original, name)
        proxy = PortProxy(native, cm=PortProxy(native.cm, load_minor=load))
        try:
            return original_authority(proxy, root, manifest, session, nonce)
        except BaseException as error:
            detail.update(error_class=type(error).__name__, error=str(error), elapsed_seconds=round(time.monotonic() - started, 6))
            diagnostic(detail)
            raise
    class SubprocessObserver:
        def __init__(self, original, label):
            self.original, self.label = original, label

        def __getattr__(self, name):
            return getattr(self.original, name)

        def run(self, *args, **kwargs):
            started = time.monotonic()
            argv = args[0] if args else kwargs.get("args")
            arguments = list(argv) if isinstance(argv, (list, tuple)) else []
            operations = {"rev-parse", "config", "cat-file", "ls-remote", "merge-base", "show", "diff", "for-each-ref", "rev-list", "status", "migrate", "archive", "check", "record"}
            detail = {"kind": "subprocess", "origin": self.label, "executable": Path(str(arguments[0])).name if arguments else None,
                      "operation": next((part for part in arguments[1:] if part in operations), "unknown"),
                      "argc": len(arguments), "timeout": kwargs.get("timeout")}
            try:
                result = self.original.run(*args, **kwargs)
            except BaseException as error:
                detail.update(error_class=type(error).__name__, errno=getattr(error, "errno", None), winerror=getattr(error, "winerror", None),
                              error=getattr(error, "strerror", None), returncode=None,
                              elapsed_seconds=round(time.monotonic() - started, 6))
                diagnostic(detail)
                raise
            expected_probe = (result.returncode == 128 and "rev-parse" in arguments and "--is-inside-work-tree" in arguments
                              and "not a git repository" in str(result.stderr).lower())
            expected_ancestry = (result.returncode == 1 and "merge-base" in arguments and "--is-ancestor" in arguments
                                 and not result.stdout and not result.stderr)
            if result.returncode != 0 and not (self.label != "helper" and (expected_probe or expected_ancestry)):
                detail.update(error_class="NonzeroExit", returncode=result.returncode,
                              stdout_length=len(result.stdout or ""), stdout_sha256=sha(result.stdout or ""),
                              stderr=result.stderr, elapsed_seconds=round(time.monotonic() - started, 6))
                diagnostic(detail)
            return result
    h.authority = observed_authority
    h.subprocess = SubprocessObserver(h.subprocess, "helper")
    if native is not None:
        native.ck.subprocess = SubprocessObserver(native.ck.subprocess, "native.check_plan_completion")
        native.ck.repo_host.subprocess = SubprocessObserver(native.ck.repo_host.subprocess, "native.repo_host")


def original_helper():
    raw = ORIGINAL.read_bytes()
    require(sha(raw) == ORIGINAL_SHA, "original helper changed")
    module = ModuleType("reviewed_original_carry_helper")
    module.__file__ = str(ORIGINAL)
    exec(compile(raw, str(ORIGINAL), "exec"), module.__dict__)
    return module


def validate_stop(h, manifest, raw, review_raw, session, nonce, stop_sha, review_sha):
    require(sha(raw) == stop_sha and sha(review_raw) == review_sha, "stopped journal or independent review changed")
    journal, review = json.loads(raw), json.loads(review_raw)
    carries = [e for e in manifest["entries"] if e["destination"]]
    require(len(carries) == 245, "wrong frozen carry count")
    require(journal["status"] == "STOPPED_REVIEW_REQUIRED" and len(journal["completed"]) == PREFIX, "not the reviewed stopped 203 prefix")
    require(journal["manifest_sha256"] == h.FROZEN_SHA, "wrong stopped manifest")
    require(journal["session"] == session and journal["nonce"] == nonce and session != "auto" and bool(nonce), "wrong session or nonce")
    amendment = journal["execution_amendment"]
    require(amendment["execution_date"] == DATE and amendment["runtime_sha256"] == h.RUNTIME_PINNED
            and amendment["helper_sha256"] == ORIGINAL_SHA, "stopped execution amendment differs")
    for completed, entry in zip(journal["completed"], carries[:PREFIX]):
        require((completed["ordinal"], completed["source_key"], completed["destination_id"])
                == (entry["ordinal"], entry["source_key"], entry["destination"]["id"]), "ordered completed prefix differs")
    pending, entry = journal["pending"], carries[PREFIX]
    require((pending["ordinal"], pending["source_key"], pending["destination_id"])
            == (entry["ordinal"], entry["source_key"], entry["destination"]["id"]), "failed pending identity differs")
    require(journal["post"] == pending["before"] == journal["completed"][-1]["after"], "failed item may have written bytes")
    require(review["status"] == "PASS_STOPPED_PREFIX_ONLY" and review["completed"] == PREFIX
            and review["remaining_open_unchanged"] == 42 and review["journal_sha256"] == stop_sha
            and review["nonce"] == nonce, "independent prefix review scope differs")
    for field in ("ordered_identities_and_numeric_ids_exact", "actual_eleven_hashes_equal_native_projection_and_last_completed_after",
                  "pending_before_equals_actual_and_journal_post", "pending_source_no_write"):
        require(review[field] is True, "independent prefix review did not prove " + field)
    require(review["actual_ledger_sha256"] == pending["before"]
            and review["verified_record_sha256"] == pending["record_sha256"], "reviewed hashes differ")
    prior = journal.get("continuation") or {}
    require(prior.get("reviewed_prefix") == 177 and prior.get("continuation_helper_sha256") == PRIOR_HELPER_SHA
            and prior.get("stopped_journal_sha256") == PRIOR_STOP_SHA and prior.get("prefix_review_sha256") == PRIOR_REVIEW_SHA
            and prior.get("preserved_stopped_journal") == str(PRIOR_STOP), "prior177 continuation provenance differs")
    history = journal.get("continuation_history")
    require(isinstance(history, list) and len(history) == 1, "older166 history differs")
    older = history[0]
    require(older.get("reviewed_prefix") == 166 and older.get("continuation_helper_sha256") == OLDER_HELPER_SHA
            and older.get("stopped_journal_sha256") == OLDER_STOP_SHA and older.get("prefix_review_sha256") == OLDER_REVIEW_SHA
            and older.get("preserved_stopped_journal") == str(OLDER_STOP), "older166 provenance differs")
    require(review.get("all203_intermediate_after_hashes_match") is True, "review did not prove every203 intermediate state")
    return journal, review, carries


def original_basis(h, native, root, manifest, basis):
    wanted = {}
    for entry in manifest["entries"]:
        path, digest = entry["current"]["ledger"], entry["current"]["file_bytes_sha256"]
        require(path not in wanted or wanted[path] == digest, "conflicting original source hashes")
        wanted[path] = digest
    require(len(wanted) == 10, "wrong original source count")
    git = native.ck.repo_host.absolute_tool("git", root)
    require(bool(git), "absolute git unavailable")
    for relative, digest in wanted.items():
        result = subprocess.run([git, "-C", str(root), "show", BASE + ":" + relative],
                                capture_output=True, check=False, timeout=30, env=native.ck._env())
        require(result.returncode == 0, "original Git source unavailable: " + relative)
        lf = result.stdout.replace(b"\r\n", b"\n")
        candidates = [result.stdout, lf, lf.replace(b"\n", b"\r\n")]
        raw = next((value for value in candidates if sha(value) == digest), None)
        require(raw is not None, "original source cannot match frozen raw hash: " + relative)
        path = h.contained(basis, relative)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
    return h.frozen_sources(basis, manifest)


def fingerprints(expected):
    return {path: sha(value) if value is not None else None for path, value in expected.items()}


def prove(h, native, root, approved, journal, review, carries, basis, session, nonce):
    require(datetime.date.today().isoformat() == DATE, "different execution date requires a new review")
    expected = original_basis(h, native, root, approved, basis)
    execution = h.execution_manifest(native, basis, approved, DATE)
    require(execution["native_preflight"]["rendered_target_sha256_utf8"]
            == "6f1e510f4db483af29b5ad543442c026c938d2064143f0821c2fa290119affc3", "date-21 final target changed")
    carries = [e for e in execution["entries"] if e["destination"]]
    expected[h.TARGET] = None
    ledgers, unreadable = native.cm.load_ledgers(basis)
    require(not unreadable, "original basis unreadable")
    for index, entry in enumerate(carries[:PREFIX]):
        plan = h.render(native, basis, execution, entry, ledgers)
        expected[plan.source.rel], expected[h.TARGET] = plan.source_after.encode(), plan.target_after.encode()
        h.update_ledger(native, ledgers, plan.source.rel, plan.source_after, basis)
        h.update_ledger(native, ledgers, h.TARGET, plan.target_after, basis)
        require(fingerprints(expected) == journal["completed"][index]["after"], "native intermediate prefix differs")
    require(fingerprints(expected) == journal["pending"]["before"] == review["actual_ledger_sha256"], "native prefix differs from reviewed state")
    h.unchanged(root, expected)
    actual, unreadable = native.cm.load_ledgers(root)
    require(not unreadable, "actual ledger unreadable")
    for entry in carries[:PREFIX]:
        source = next(l for l in actual if l.rel == entry["current"]["ledger"])
        matches = native.cm.gap_items(source.items, entry["source_key"])
        require(not source.problems and len(matches) == 1 and matches[0].state == "migrated", "completed source is not migrated")
        reason, found = native.cm.migration_copy_status(actual, "v2.16.0", source, matches[0], label=entry["source_key"], require_reason=True)
        require(reason == "migration-copy-complete" and found is not None
                and found[1].gid == entry["destination"]["id"] and found[1].body == entry["destination"]["proposed_body"], "completed native copy differs")
    work = list(actual)
    for index, entry in enumerate(carries[PREFIX:]):
        plan = h.render(native, root, execution, entry, work)
        if index == 0:
            require({plan.source.rel: sha(plan.source_after), h.TARGET: sha(plan.target_after)} == journal["pending"]["expected_after"], "failed item prediction changed")
        h.update_ledger(native, work, plan.source.rel, plan.source_after, root)
        h.update_ledger(native, work, h.TARGET, plan.target_after, root)
    require(sha(next(l.text for l in work if l.rel == h.TARGET)) == execution["native_preflight"]["rendered_target_sha256_utf8"], "remaining 42 native bodies changed")
    record = h.authority(native, root, execution, session, nonce)
    require(record.loaded_sha256 == journal["pending"]["record_sha256"]
            and sha(record.record_path.read_bytes()) == record.loaded_sha256, "verified record changed")
    return SimpleNamespace(manifest=execution, carries=carries, expected=expected, record_sha=record.loaded_sha256)


class JournalWriter:
    def __init__(self, h, path, guard, digest, output, pins):
        self.h, self.path, self.guard, self.digest, self.output, self.pins = h, path, guard, digest, output, pins

    def write(self, value):
        self.h.check_pins(self.pins)
        self.h.guard(self.guard, "check", self.path)
        require(sha(self.path.read_bytes()) == self.digest, "canonical journal changed")
        raw = (json.dumps(value, ensure_ascii=True, indent=2) + "\n").replace("\n", os.linesep).encode()
        descriptor, name = tempfile.mkstemp(prefix=self.path.name + ".continuation-", suffix=".tmp", dir=self.path.parent)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        self.h.guard(self.guard, "check", self.path)
        require(sha(self.path.read_bytes()) == self.digest, "canonical journal changed before replacement")
        os.replace(name, self.path)
        require(self.path.read_bytes() == raw, "canonical journal changed after replacement")
        self.h.guard(self.guard, "record", self.path, "write")
        require(self.path.read_bytes() == raw, "canonical journal changed during guard recording")
        self.digest = sha(raw)

    def stop(self, journal, error, root, expected):
        failure = copy.deepcopy(journal)
        failure.update(status="STOPPED_REVIEW_REQUIRED", error=type(error).__name__ + ": " + str(error), post=self.h.fingerprints(root, expected))
        try:
            self.write(failure)
            failure["canonical_journal_updated"] = True
        except BaseException as journal_error:
            failure.update(canonical_journal_updated=False, journal_update_error=type(journal_error).__name__ + ": " + str(journal_error))
        path = self.output / "continuation-failure.json"
        with path.open("xb") as stream:
            stream.write((json.dumps(failure, ensure_ascii=True, indent=2) + "\n").encode())


class ContinuationLease:
    """One reviewed invocation; a failed or crashed owner needs manual review."""
    def __init__(self, path, metadata):
        self.path = path
        self.raw = (json.dumps(metadata, ensure_ascii=True, sort_keys=True) + "\n").encode()

    def acquire(self):
        with self.path.open("xb") as stream:
            stream.write(self.raw)
            stream.flush()
            os.fsync(stream.fileno())

    def complete(self):
        require(self.path.read_bytes() == self.raw, "continuation lease changed; manual review required")
        self.path.unlink()


def continue_once(h, native, root, hub, proof, journal, session, nonce, pins, guard, writer):
    expected = dict(proof.expected)

    def authority():
        record = h.authority(native, root, proof.manifest, session, nonce)
        require(record.loaded_sha256 == proof.record_sha and sha(record.record_path.read_bytes()) == proof.record_sha, "record race or replacement")
        return record

    try:
        h.check_pins(pins)
        h.unchanged(root, expected)
        authority()
        require(datetime.date.today().isoformat() == DATE, "execution date changed before journal transition")
        writer.write(journal)
        for entry in proof.carries[PREFIX:]:
            h.check_pins(pins)
            h.unchanged(root, expected)
            authority()
            ledgers, unreadable = native.cm.load_ledgers(root)
            require(not unreadable, "unreadable ledger")
            plan = h.render(native, root, proof.manifest, entry, ledgers)
            dry = h.run(h.cli(hub, root, proof.manifest, entry, session, dry=True))
            require(f"WOULD MIGRATE {entry['source_key']} -> v2.16#{plan.new_gid} " in dry.stdout, "unexpected dry-run allocation")
            h.check_pins(pins)
            h.unchanged(root, expected)
            record = authority()
            for relative in (plan.source.rel, h.TARGET):
                h.guard(guard, "check", h.contained(root, relative))
            h.check_pins(pins)
            h.unchanged(root, expected)
            require(sha(record.record_path.read_bytes()) == proof.record_sha, "record changed before native write")
            journal["pending"] = {"ordinal": entry["ordinal"], "source_key": entry["source_key"], "destination_id": plan.new_gid,
                                  "before": h.fingerprints(root, expected), "record_sha256": proof.record_sha,
                                  "expected_after": {plan.source.rel: sha(plan.source_after), h.TARGET: sha(plan.target_after)}}
            writer.write(journal)
            h.unchanged(root, expected)
            authority()
            require(datetime.date.today().isoformat() == DATE, "execution date changed before native write")
            actual = h.run(h.cli(hub, root, proof.manifest, entry, session, dry=False))
            require(f"MIGRATED {entry['source_key']} -> v2.16#{plan.new_gid} " in actual.stdout, "unexpected native write result")
            expected[plan.source.rel], expected[h.TARGET] = plan.source_after.encode(), plan.target_after.encode()
            h.unchanged(root, expected)
            h.check_pins(pins)
            authority()
            for relative in (plan.source.rel, h.TARGET):
                h.guard(guard, "record", h.contained(root, relative), "write")
            journal["completed"].append({"ordinal": entry["ordinal"], "source_key": entry["source_key"], "destination_id": plan.new_gid,
                                         "after": h.fingerprints(root, expected)})
            journal["pending"] = None
            writer.write(journal)
            if len(journal["completed"]) % 25 == 0:
                print(json.dumps({"completed": len(journal["completed"]), "total": 245}), flush=True)
        require(len(journal["completed"]) == 245 and sha(expected[h.TARGET]) == proof.manifest["native_preflight"]["rendered_target_sha256_utf8"], "incomplete continuation or final target differs")
        h.unchanged(root, expected)
        authority()
        h.check_pins(pins)
        journal["status"] = "COMPLETE_CARRIES_ONLY"
        writer.write(journal)
    except BaseException as error:
        writer.stop(journal, error, root, expected)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--session", required=True)
    parser.add_argument("--nonce", required=True)
    parser.add_argument("--continue-reviewed-prefix", type=int, choices=[PREFIX])
    parser.add_argument("--stopped-journal-sha256")
    parser.add_argument("--prefix-review-sha256")
    parser.add_argument("--reviewed-prior-lease-sha256")
    parser.add_argument("--output-dir", type=Path)
    args = parser.parse_args()
    writing = args.continue_reviewed_prefix is not None
    require(not writing or (args.stopped_journal_sha256 == STOP_SHA and args.prefix_review_sha256 == REVIEW_SHA
                           and args.reviewed_prior_lease_sha256 == PRIOR_LEASE_SHA), "continuation needs all exact reviewed receipt hashes")
    require(args.stopped_journal_sha256 in (None, STOP_SHA) and args.prefix_review_sha256 in (None, REVIEW_SHA), "wrong receipt hash")
    require(args.reviewed_prior_lease_sha256 in (None, PRIOR_LEASE_SHA), "wrong prior lease review hash")
    h = original_helper()
    approved_raw = (ROOT / h.MANIFEST).read_bytes()
    require(sha(approved_raw) == h.FROZEN_SHA, "frozen manifest changed")
    approved = json.loads(approved_raw)
    raw, review_raw = JOURNAL.read_bytes(), REVIEW.read_bytes()
    journal, review, carries = validate_stop(h, approved, raw, review_raw, args.session, args.nonce, STOP_SHA, REVIEW_SHA)
    prior_raw = PRIOR_LEASE.read_bytes()
    prior = validate_prior_lease(prior_raw, args.session, args.nonce)
    require(sha(PRIOR_STOP.read_bytes()) == PRIOR_STOP_SHA, "original177 stopped receipt changed")
    guard = CANONICAL_GUARD
    older_raw = OLDER_LEASE.read_bytes()
    validate_older_lease(older_raw, args.session, args.nonce)
    pins = {HUB / name: digest for name, digest in h.RUNTIME_PINNED.items()}
    pins.update({ROOT / h.MANIFEST: h.FROZEN_SHA, ORIGINAL: ORIGINAL_SHA, Path(__file__).resolve(): sha(Path(__file__).read_bytes()),
                 ROOT / ".nexus-hub/validate-carry-forward-manifest.py": approved["native_preflight"]["validation_helper_sha256"],
                 REVIEW: REVIEW_SHA, guard: CANONICAL_GUARD_SHA, PRIOR_LEASE: PRIOR_LEASE_SHA, PRIOR_STOP: PRIOR_STOP_SHA,
                 OLDER_LEASE: OLDER_LEASE_SHA, OLDER_STOP: OLDER_STOP_SHA, GUARD_QUALIFICATION: GUARD_QUALIFICATION_SHA})
    pins.update({h.contained(ROOT, entry["path"]): entry["sha256"] for entry in approved["inputs"]})
    h.check_pins(pins)
    native = h.native_modules(HUB, h.RUNTIME_PINNED)
    output = args.output_dir.resolve() if args.output_dir else Path(tempfile.mkdtemp(prefix="nexus-prefix203-proof-"))
    if args.output_dir:
        require(output.is_relative_to(Path(tempfile.gettempdir()).resolve()), "output must be a new private temporary directory")
        output.mkdir(mode=0o700)
    require(not output.is_relative_to(ROOT.resolve()) and not output.is_relative_to(HUB.parent.resolve()), "output inside repository")
    basis = output / "original-basis"
    basis.mkdir()
    install_observers(h, output, native)
    proof = prove(h, native, ROOT, approved, journal, review, carries, basis, args.session, args.nonce)
    h.check_pins(pins)
    require(JOURNAL.read_bytes() == raw and REVIEW.read_bytes() == review_raw, "reviewed inputs changed during proof")
    result = {"status": "PASS_STOPPED_PREFIX_ONLY", "completed": PREFIX, "remaining_open_unchanged": 42,
              "stopped_journal_sha256": STOP_SHA, "independent_prefix_review_sha256": REVIEW_SHA,
              "current_hashes": fingerprints(proof.expected), "final_date21_target_sha256": proof.manifest["native_preflight"]["rendered_target_sha256_utf8"],
              "record_sha256": proof.record_sha, "continuation_requested": writing, "production_writes": False,
              "guard_tool": str(guard), "guard_sha256": CANONICAL_GUARD_SHA, "guard_qualification_sha256": GUARD_QUALIFICATION_SHA}
    h.write_json(output / "prefix-proof.json", result)
    print(json.dumps({"private_output": str(output), **result}), flush=True)
    if not writing:
        return
    lease = ContinuationLease(JOURNAL.with_name(JOURNAL.name + ".reviewed-prefix203-continuation.lock"), {
        "pid": os.getpid(), "session": args.session, "nonce": args.nonce, "stopped_journal_sha256": STOP_SHA,
        "prefix_review_sha256": REVIEW_SHA, "helper_sha256": sha(Path(__file__).read_bytes()), "execution_date": DATE})
    lease.acquire()
    validate_prior_lease(PRIOR_LEASE.read_bytes(), args.session, args.nonce)
    validate_older_lease(OLDER_LEASE.read_bytes(), args.session, args.nonce)
    prior_copy = output / "retained-prefix177-invocation-lease.raw.json"
    with prior_copy.open("xb") as stream:
        stream.write(prior_raw)
        stream.flush()
        os.fsync(stream.fileno())
    require(sha(prior_copy.read_bytes()) == PRIOR_LEASE_SHA, "preserved prior lease differs")
    os.chmod(prior_copy, 0o400)
    pins[prior_copy] = PRIOR_LEASE_SHA
    preserved = output / "stopped-prefix203-journal.raw.json"
    with preserved.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    require(sha(preserved.read_bytes()) == STOP_SHA, "preserved stopped receipt differs")
    os.chmod(preserved, 0o400)
    pins[preserved] = STOP_SHA
    retained = []
    for source, digest, name in [(OLDER_LEASE, OLDER_LEASE_SHA, "retained-prefix166-invocation-lease.raw.json"),
                                  (OLDER_STOP, OLDER_STOP_SHA, "stopped-prefix166-journal.raw.json"),
                                  (PRIOR_STOP, PRIOR_STOP_SHA, "stopped-prefix177-journal.raw.json")]:
        saved = output / name
        value = source.read_bytes()
        require(sha(value) == digest, "older static receipt changed")
        with saved.open("xb") as stream:
            stream.write(value)
            stream.flush()
            os.fsync(stream.fileno())
        require(sha(saved.read_bytes()) == digest, "older receipt copy differs")
        os.chmod(saved, 0o400)
        pins[saved] = digest
        retained.append({"source": str(source), "preserved": str(saved), "sha256": digest})
    journal.setdefault("continuation_history", []).append(copy.deepcopy(journal["continuation"]))
    journal["continuation"] = {"reviewed_prefix": PREFIX, "stopped_journal_sha256": STOP_SHA, "preserved_stopped_journal": str(preserved),
        "prefix_review_sha256": REVIEW_SHA, "continuation_helper_sha256": sha(Path(__file__).read_bytes()), "original_helper_sha256": ORIGINAL_SHA,
        "execution_date": DATE, "original_stop_status": journal["status"], "original_stop_error": journal["error"],
        "prior_lease_sha256": PRIOR_LEASE_SHA, "preserved_prior_lease": str(prior_copy), "prior_pid": prior["pid"],
        "retained_older_receipts": retained, "guard_tool": str(guard), "guard_sha256": CANONICAL_GUARD_SHA,
        "guard_qualification_sha256": GUARD_QUALIFICATION_SHA,
        "prior_lease_policy": "Explicit manually reviewed prior leases remain unchanged; separate exclusive203 invocation lease.",
        "cause": "The203 stop captured installed guard metadata-log os.replace PermissionError WinError5, with no pending-item ledger write. Reuse qualified existing canonical guard e950 atomic metadata handling; no installation or native source change and no command retry. Earlier166/177 causes remain unproven."}
    journal["status"] = "CONTINUATION_REVIEWED_PREFIX"
    writer = JournalWriter(h, JOURNAL, guard, STOP_SHA, output, pins)
    continue_once(h, native, ROOT, HUB, proof, journal, args.session, args.nonce, pins, guard, writer)
    lease.complete()
    print(json.dumps({"status": "COMPLETE_CARRIES_ONLY", "completed": 245, "journal": str(JOURNAL), "private_output": str(output)}), flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(type(error).__name__ + ": " + str(error), file=sys.stderr)
        raise SystemExit(1)
