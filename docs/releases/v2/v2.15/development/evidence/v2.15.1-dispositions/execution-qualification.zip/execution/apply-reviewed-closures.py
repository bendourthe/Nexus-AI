"""Apply only the 14 exact independently qualified closure patches after all carries."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from types import ModuleType

ROOT = Path("C:/nx-close").resolve()
HUB = Path("C:/nh-checker/scripts").resolve()
OUTPUT = Path("C:/Users/bdour/AppData/Local/Temp/nexus-v215-carry-20261021-375a11466cff")
QUAL = Path("C:/Users/bdour/AppData/Local/Temp/nexus-independent-closure-qualification-wbupg_ve/qualification.json")
HELPER_SHA = "bb37d90e74488bff80d24b3328460b37f486116dbdcce1d3ba1c50764202db51"
QUAL_SHA = "4e1aaeb3f92f25ae9ade095abcb130339fde914f15efc353360e864dbc160a62"
SESSION = "01a15bc3-38c8-7cc0-ba5c-813feba8c119"
NONCE = "c9ec5a2b3afd94d05bac5c4b6e0c5a48"

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    helper_path = ROOT / ".nexus-hub/apply-carry-forward-manifest.py"
    helper_raw = helper_path.read_bytes()
    if hashlib.sha256(helper_raw).hexdigest() != HELPER_SHA:
        raise RuntimeError("qualified helper changed")
    h = ModuleType("qualified_carry_helper")
    h.__file__ = str(helper_path)
    exec(compile(helper_raw, str(helper_path), "exec"), h.__dict__)
    h.require(h.sha(QUAL.read_bytes()) == QUAL_SHA, "independent qualification changed")
    qualification = json.loads(QUAL.read_text())
    manifest_path = ROOT / h.MANIFEST
    h.require(h.sha(manifest_path.read_bytes()) == h.FROZEN_SHA, "approved manifest changed")
    manifest = json.loads(manifest_path.read_text())
    journal = json.loads((OUTPUT / "completed-prefix-journal.json").read_text())
    h.require(journal["status"] == "COMPLETE_CARRIES_ONLY" and len(journal["completed"]) == 245 and journal["pending"] is None, "all 245 carries must finish first")
    h.require(journal["session"] == SESSION and journal["nonce"] == NONCE and journal["manifest_sha256"] == h.FROZEN_SHA, "wrong carry authority")
    date = journal["execution_amendment"]["execution_date"]
    h.require(str(datetime.date.today()) == date, "do not backdate closure execution")
    expected = dict(journal["completed"][-1]["after"])
    h.require(len(expected) == 11 and h.fingerprints(ROOT, expected) == expected, "post-carry ledger state changed")
    previews = json.loads((OUTPUT / "closure-previews.json").read_text())["entries"]
    entries = [e for e in manifest["entries"] if not e["destination"] and e["disposition"] != "already-resolved"]
    proofs = qualification["patches"]
    h.require(len(entries) == len(previews) == len(proofs) == 14, "wrong closure count")
    patches = []
    for entry, preview, proof in zip(entries, previews, proofs):
        h.require(entry["source_key"] == preview["source_key"] == proof["source_key"], "closure identity changed")
        h.require(preview["ledger"] == proof["only_changed_file"] == entry["current"]["ledger"], "closure path changed")
        h.require(preview["before_sha256"] == proof["before_sha256"] and preview["proposed_after_sha256"] == proof["after_sha256"], "closure hashes changed")
        path = OUTPUT / f"closure-{entry['ordinal']:03d}.patch"
        raw = path.read_bytes()
        h.require(h.sha(raw) == proof["patch_sha256"], "qualified patch changed")
        patches.append(raw)
    projected = dict(expected)
    for preview in previews:
        relative = preview["ledger"]
        h.require(projected[relative] == preview["before_sha256"], "qualified closure chain mismatch")
        projected[relative] = preview["proposed_after_sha256"]
    h.require(projected == qualification["final_ledger_hashes"], "all eleven final hashes must match independent qualification")
    guard = Path("C:/nh-checker/catalog/skills/workflow/user-edit-preservation/scripts/edit_guard.py")
    pins = {HUB / name: value for name, value in h.RUNTIME_PINNED.items()}
    pins.update({helper_path: HELPER_SHA, QUAL: QUAL_SHA, manifest_path: h.FROZEN_SHA, guard: "e950fdbc10cdcf0853c0eb878d8c9345d0ebdbcb61a62f787fbd5cd5aecf22af", Path(__file__).resolve(): h.sha(Path(__file__).read_bytes())})
    pins.update({h.contained(ROOT, item["path"]): item["sha256"] for item in manifest["inputs"]})
    h.check_pins(pins)
    native = h.native_modules(HUB, h.RUNTIME_PINNED)
    context = native.ck.RepoContext(ROOT, native.ck.Budget(180))
    result_path = OUTPUT / "closure-application-journal.json"
    h.require(not result_path.exists(), "closure run already exists; review instead of resuming")
    result = {"status": "PREVIEW", "manifest_sha256": h.FROZEN_SHA, "session": SESSION, "nonce": NONCE, "date": date, "completed": [], "pending": None}
    def git_apply(raw, check=False):
        command = ["git", "-C", str(ROOT), "--work-tree", str(ROOT), "apply", "-p0"] + (["--check"] if check else []) + ["-"]
        clean_env = {key: value for key, value in os.environ.items() if not key.upper().startswith("GIT_")}
        completed = subprocess.run(command, input=raw, capture_output=True, timeout=60, env=clean_env, cwd=ROOT)
        h.require(completed.returncode == 0, "Git patch refused: " + completed.stderr.decode("utf-8", "replace")[-1500:])
    with native.ck.minor_creation_lease(context, "v2.15"):
        native.cm.check_successor_transition(native.ck, context, "v2.15")
        h.check_pins(pins)
        h.require(not result_path.exists(), "closure run appeared while waiting for lease; review instead of resuming")
        h.require(h.fingerprints(ROOT, expected) == expected, "ledger state changed while waiting for lease")
        h.authority(native, ROOT, manifest, SESSION, NONCE)
        if not args.apply:
            print(json.dumps({"status": "WOULD_APPLY", "closures": 14, "ledgers_unchanged": True}))
            return
        result["status"] = "STARTED"
        h.write_json(result_path, result)
        try:
            for entry, preview, raw in zip(entries, previews, patches):
                h.check_pins(pins)
                h.require(h.fingerprints(ROOT, expected) == expected, "concurrent ledger change")
                relative = preview["ledger"]
                h.require(expected[relative] == preview["before_sha256"], "closure before hash mismatch")
                record = h.authority(native, ROOT, manifest, SESSION, NONCE)
                record_hash = record.loaded_sha256
                h.guard(guard, "check", h.contained(ROOT, relative))
                git_apply(raw, check=True)
                h.check_pins(pins)
                h.require(h.fingerprints(ROOT, expected) == expected and h.sha(record.record_path.read_bytes()) == record_hash, "state changed before patch")
                result["pending"] = {"source_key": entry["source_key"], "ledger": relative, "before_sha256": expected[relative], "after_sha256": preview["proposed_after_sha256"], "record_sha256": record_hash}
                h.write_json(result_path, result)
                git_apply(raw)
                expected[relative] = preview["proposed_after_sha256"]
                h.require(h.fingerprints(ROOT, expected) == expected, "unexpected patch result")
                h.require(h.sha(record.record_path.read_bytes()) == record_hash, "authority changed during patch")
                h.guard(guard, "record", h.contained(ROOT, relative), "write")
                h.authority(native, ROOT, manifest, SESSION, NONCE)
                result["completed"].append(result["pending"])
                result["pending"] = None
                h.write_json(result_path, result)
            h.check_pins(pins)
            h.require(h.fingerprints(ROOT, qualification["final_ledger_hashes"]) == qualification["final_ledger_hashes"], "final ledger hashes differ from independent qualification")
            result.update(status="COMPLETE_CLOSURES", final_sha256=expected, completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
        except BaseException as error:
            result.update(status="STOPPED_REVIEW_REQUIRED", error=type(error).__name__ + ": " + str(error), post_sha256=h.fingerprints(ROOT, expected))
            h.write_json(result_path, result)
            raise
        h.write_json(result_path, result)
    print(json.dumps({"status": result["status"], "closures_applied": len(result["completed"]), "journal": str(result_path)}))

if __name__ == "__main__":
    main()
