"""Validate the frozen carry proposal; apply only through its approved native CLI."""

from __future__ import annotations

import argparse
import difflib
import copy
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
from dataclasses import replace
from pathlib import Path
from types import ModuleType, SimpleNamespace

sys.dont_write_bytecode = True
MANIFEST = "docs/releases/v2/v2.15/development/v2.15.4-carry-forward-manifest.json"
TARGET = "docs/releases/v2/v2.16/known-gaps.md"
FROZEN_SHA = "a1d392405d27d08bbf23ea13f159a3842910c7b8608228f54b828be06cbc4fc3"
PINNED = {
    "check_plan_completion.py": "5abab5b5f5007b82763d68137b7c500b1f005515f42efb31e7e331269d27eb82",
    "completion_minor.py": "3e458ba449865aab20306ce61a71e562915fd6f41e2ec4a2e1249b065dbccc1b",
    "minor_close.py": "4dbbcfe2f2ce7e4e88bcce91673a7a92be95e0d7c431dc8ab8d32013eaa4303b",
    "approval_page.py": "ca06b8aa99e6a6e686fee981710d2a971aedac07e65ad2a43852369291ef96ad",
}
RUNTIME_PINNED = {
    "approval_page.py": "ca06b8aa99e6a6e686fee981710d2a971aedac07e65ad2a43852369291ef96ad",
    "approval_binding.py": "bbd1863ece314addd28f5c7d3c2caf304a6f4dbaefc37f9c55daa03117dd486b",
    "repo_host.py": "dfeec69940715ad782a0885a6426214e2bce13c9d33ad41ecc6975a23f3147a7",
    "check_plan_completion.py": "f65929999a637c8e9ec05131c176450c5792bd27462b757792ac59cb8ff10ad6",
    "completion_minor.py": "6ee9267c70b17fe774b82028372e727ef2d1b2ae89c569580ca1d6e5c5809a02",
    "minor_close.py": "c5ef652b4bbabaaa3557a09da2db0b96176bdf8d121d6bd13af68fc790056a1a"
}  # Frozen candidate; actual apply still requires final independent native qualification.
MODULES = ("approval_page", "approval_binding", "repo_host", "check_plan_completion", "completion_minor", "minor_close")


def require(ok: bool, reason: str) -> None:
    if not ok:
        raise ValueError(reason)


def sha(value: bytes | str) -> str:
    return hashlib.sha256(value.encode("utf-8") if isinstance(value, str) else value).hexdigest()


def contained(root: Path, relative: str) -> Path:
    result = root / relative
    require(not result.is_symlink() and result.resolve().is_relative_to(root), "unsafe repository path: " + relative)
    return result


def read_optional(path: Path) -> bytes | None:
    return path.read_bytes() if path.exists() else None


def fingerprints(root: Path, expected: dict[str, bytes | None]) -> dict:
    result = {}
    for relative in expected:
        try:
            data = read_optional(contained(root, relative))
            result[relative] = sha(data) if data is not None else None
        except (OSError, ValueError) as error:
            result[relative] = {"unreadable": type(error).__name__ + ": " + str(error)}
    return result


def frozen_sources(root: Path, manifest: dict) -> dict[str, bytes | None]:
    expected = {}
    for entry in manifest["entries"]:
        current = entry["current"]
        raw = contained(root, current["ledger"]).read_bytes()
        require(sha(raw) == current["file_bytes_sha256"], "source changed since frozen preflight: " + current["ledger"])
        expected[current["ledger"]] = raw
    return expected


def unchanged(root: Path, expected: dict[str, bytes | None]) -> None:
    for relative, before in expected.items():
        require(read_optional(contained(root, relative)) == before, "concurrent edit or unexpected output: " + relative)


def run(arguments: list[str], *, timeout: int = 240) -> subprocess.CompletedProcess:
    result = subprocess.run(arguments, capture_output=True, text=True, timeout=timeout, check=False)
    require(result.returncode == 0, "native command refused: " + (result.stdout + result.stderr)[-2000:])
    return result


def write_json(path: Path, value: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
    os.chmod(temporary, 0o600)
    os.replace(temporary, path)


def check_pins(pins: dict[Path, str]) -> None:
    for path, frozen in pins.items():
        require(path.is_file() and sha(path.read_bytes()) == frozen, "pinned input changed: " + str(path))


def native_modules(hub: Path, hashes: dict[str, str]) -> SimpleNamespace:
    snapshots = {name: (hub / (name + ".py")).read_bytes() for name in MODULES}
    for name, raw in snapshots.items():
        require(sha(raw) == hashes[name + ".py"], "unqualified module snapshot: " + name)
    for name in MODULES:
        module = ModuleType(name)
        module.__file__ = str(hub / (name + ".py"))
        sys.modules[name] = module
        exec(compile(snapshots[name], module.__file__, "exec"), module.__dict__)
    return SimpleNamespace(ck=sys.modules["check_plan_completion"], cm=sys.modules["completion_minor"], mc=sys.modules["minor_close"])


def authority(native: SimpleNamespace, root: Path, manifest: dict, session: str, nonce: str):
    require(bool(session) and session != "auto" and bool(nonce), "explicit real session and record nonce required")
    context = native.ck.RepoContext(root, native.ck.Budget(180))
    loaded = native.cm.load_minor(native.ck, context, "v2.15", session)
    require(loaded.forced is None and loaded.record is not None, "no usable verified minor record")
    record = loaded.record
    require(record.get("schema") == 2 and record.get("scope") == "minor" and record.get("minor") == "v2.15", "wrong record scope")
    require(record.get("session_id") == session and record.get("nonce") == nonce, "wrong session or record nonce")
    for field in ("repo_root", "worktree"):
        value = record.get(field)
        require(isinstance(value, str) and bool(value) and Path(value).is_absolute() and Path(value).resolve() == root,
                "record is not explicitly bound to this worktree: " + field)
    classes = [entry for entry in (record.get("approvals") or {}).get("classes", []) if entry.get("class") == "gap-migration"]
    require(len(classes) == 1, "exactly one frozen gap-migration class required")
    entry = classes[0]
    for name in ("bound", "named"):
        values = entry.get(name)
        expected = manifest["approval"][name]
        require(isinstance(values, list) and len(values) == 245 and all(isinstance(value, str) for value in values)
                and len(set(values)) == 245 and set(values) == set(expected), "frozen " + name + " is not the exact 245 identities")
    require(entry.get("manifest_sha256") == FROZEN_SHA, "record class does not bind this frozen manifest")
    require(not record.get("completed") and not record.get("pause") and not any(b.get("open") for b in record.get("blockers", [])), "record is completed, paused or blocked")
    return record


def cli(hub: Path, root: Path, manifest: dict, entry: dict, session: str, *, dry: bool) -> list[str]:
    arguments = [sys.executable, "-I", str(hub / "minor_close.py"), "migrate", "--minor", "v2.15", "--repo", str(root),
                 "--session", session, "--id", entry["source_key"], "--to", "v2.16.0", "--reason", "user-deferred",
                 "--evidence", entry["migration_evidence"], "--date", manifest["recorded_date"]]
    return arguments + (["--dry-run"] if dry else [])


def render(native: SimpleNamespace, root: Path, manifest: dict, entry: dict, ledgers: list):
    source = next(ledger for ledger in ledgers if ledger.rel == entry["current"]["ledger"])
    matches = native.cm.gap_items(source.items, entry["source_key"])
    require(not source.problems and len(matches) == 1 and matches[0].state == "open", "source is not one open item: " + entry["source_key"])
    target = next((ledger for ledger in ledgers if ledger.rel == TARGET), None)
    plan = native.mc._migration_texts(SimpleNamespace(root=root), entry["source_key"], source, matches[0], "v2.16",
        (root / TARGET, TARGET, target.text if target else None), "user-deferred", entry["migration_evidence"],
        manifest["recorded_date"], label=entry["source_key"], ledgers=ledgers)
    items, problems = native.cm.parse_ledger_full(plan.target_after)
    copies = [item for item in items if item.gid == plan.new_gid]
    wanted = entry["destination"]
    require(not problems and len(copies) == 1 and copies[0].state == "open", "rendered destination is not open and unique")
    copy = copies[0]
    require(plan.new_gid == wanted["id"] and copy.gid + copy.title == wanted["title"]
            and copy.body == wanted["proposed_body"] and sha(copy.body) == wanted["proposed_body_sha256_utf8"],
            "native destination differs from frozen manifest: " + entry["source_key"])
    return plan


def execution_manifest(native: SimpleNamespace, root: Path, approved: dict, execution_date: str) -> dict:
    """Preserve the approved proposal; date only its new migration provenance honestly."""
    require(datetime.date.fromisoformat(execution_date).isoformat() == execution_date, "invalid execution date")
    require(execution_date == datetime.date.today().isoformat(), "execution date must be the current host date")
    proposed_date = approved["recorded_date"]
    require(execution_date >= proposed_date, "execution cannot precede the frozen proposal")
    result = copy.deepcopy(approved)
    result["recorded_date"] = execution_date
    for entry in (e for e in result["entries"] if e["destination"]):
        destination = entry["destination"]
        copied = destination["copied_body"]
        body = destination["proposed_body"]
        require(body.startswith(copied), "approved copy prefix differs: " + entry["source_key"])
        prefix = "- **Migrated from**: " + entry["source_key"] + " on " + proposed_date + " (reason: user-deferred)"
        suffix = body[len(copied):]
        padding = "\r\n" if suffix.startswith("\r\n") else "\n" if suffix.startswith("\n") else ""
        suffix = suffix[len(padding):]
        require(suffix.startswith(prefix + "\n") or suffix.startswith(prefix + "\r\n"), "unrecognized frozen migration provenance")
        replacement = "- **Migrated from**: " + entry["source_key"] + " on " + execution_date + " (reason: user-deferred)"
        destination["proposed_body"] = copied + padding + replacement + suffix[len(prefix):]
        destination["proposed_body_sha256_utf8"] = sha(destination["proposed_body"])
    ledgers, unreadable = native.cm.load_ledgers(root)
    require(not unreadable, "unreadable execution source")
    for entry in (e for e in result["entries"] if e["destination"]):
        plan = render(native, root, result, entry, ledgers)
        update_ledger(native, ledgers, plan.source.rel, plan.source_after, root)
        update_ledger(native, ledgers, TARGET, plan.target_after, root)
    result["native_preflight"]["rendered_target_sha256_utf8"] = sha(next(l.text for l in ledgers if l.rel == TARGET))
    result["execution_amendment"] = {"frozen_manifest_sha256": FROZEN_SHA, "proposal_date": proposed_date,
        "execution_date": execution_date, "time_basis": "host-local calendar captured at invocation",
        "host_timezone": datetime.datetime.now().astimezone().tzname(), "runtime_sha256": dict(RUNTIME_PINNED),
        "helper_sha256": sha(Path(__file__).read_bytes()), "changed_scope": "Only appended migration dates and derived headers; all approved IDs, copied bodies, reasons and evidence stay exact."}
    return result


def update_ledger(native: SimpleNamespace, ledgers: list, relative: str, text: str, root: Path) -> None:
    items, problems = native.cm.parse_ledger_full(text)
    require(not problems, "rendered ledger parser problem: " + relative)
    for index, ledger in enumerate(ledgers):
        if ledger.rel == relative:
            ledgers[index] = replace(ledger, text=text, items=items, problems=problems)
            return
    require(relative == TARGET, "unexpected new ledger")
    ledgers.append(native.cm.Ledger(root / relative, relative, (2, 16), "active", text, items, problems))


def closure_previews(native: SimpleNamespace, root: Path, manifest: dict, output: Path) -> None:
    ledgers, unreadable = native.cm.load_ledgers(root)
    require(not unreadable, "unreadable source")
    for entry in (entry for entry in manifest["entries"] if entry["destination"]):
        plan = render(native, root, manifest, entry, ledgers)
        update_ledger(native, ledgers, plan.source.rel, plan.source_after, root)
        update_ledger(native, ledgers, TARGET, plan.target_after, root)
    summaries = []
    for entry in (entry for entry in manifest["entries"] if not entry["destination"] and entry["disposition"] != "already-resolved"):
        source = next(ledger for ledger in ledgers if ledger.rel == entry["current"]["ledger"])
        matches = native.cm.gap_items(source.items, entry["source_key"])
        require(len(matches) == 1 and matches[0].state == "open", "closure preview needs one open source")
        item = matches[0]
        for evidence in entry["evidence"]:
            require(contained(root, evidence).is_file(), "missing closure evidence: " + evidence)
        nl = native.mc._newline(source.text)
        note = nl.join(["", "- **Resolution in v2.15.1**: " + entry["justification"],
                        "- **Evidence**: " + "; ".join(entry["evidence"]), "- **Limits**: " + entry["limits"], ""])
        after = source.text[:item.end] + note + source.text[item.end:]
        after = after[:item.heading_end] + " - RESOLVED " + manifest["recorded_date"] + after[item.heading_end:]
        after = native.mc._adjust_summary(after, item.section, item.kind, source.text)
        after = native.mc._set_header(after, manifest["recorded_date"])
        # A closure increments the derived resolved column; never rewrite original bodies.
        head = native.mc._find_heading(after, 2, lambda title: title == item.section)
        end = native.mc._block_end(after, head, 2)
        count = sum(i.section == item.section and i.kind == item.kind and i.state == "resolved" for i in native.cm.parse_ledger(after))
        row = re.search(r"^(\|[^|\n]*\(" + item.kind + r"\)[^|\n]*\|\s*\d+\s*\|\s*)(\d+)(\s*\|)", after[head:end], re.MULTILINE)
        if row:
            start = head + row.start(2)
            after = after[:start] + str(count) + after[head + row.end(2):]
        closed = native.cm.gap_items(native.cm.parse_ledger(after), entry["source_key"])
        require(len(closed) == 1 and closed[0].state == "resolved" and closed[0].body.startswith(item.body),
                "closure preview changed original body or failed to resolve: " + entry["source_key"])
        patch = "".join(difflib.unified_diff(source.text.splitlines(keepends=True), after.splitlines(keepends=True),
                                          fromfile=source.rel, tofile=source.rel))
        (output / (f"closure-{entry['ordinal']:03d}.patch")).write_text(patch, encoding="utf-8", newline="")
        summaries.append({"source_key": entry["source_key"], "ledger": source.rel, "before_sha256": sha(source.text),
                          "proposed_after_sha256": sha(after), "proof": entry["evidence"], "authority": "PREVIEW ONLY; not applied"})
        update_ledger(native, ledgers, source.rel, after, root)
    require(len(summaries) == 14, "expected exactly 14 closure previews")
    write_json(output / "closure-previews.json", {"status": "PREVIEW ONLY", "after": "245 projected native carries", "entries": summaries})


def guard(tool: Path, action: str, path: Path, origin: str | None = None) -> None:
    arguments = [sys.executable, "-I", str(tool), "--session", "nexus-ai-archive-readiness", action, str(path)]
    if origin:
        arguments += ["--from", origin]
    run(arguments)


def apply_carries(native: SimpleNamespace, root: Path, hub: Path, manifest: dict, session: str, nonce: str,
                  pins: dict[Path, str], output: Path, guard_tool: Path) -> dict:
    expected = frozen_sources(root, manifest)
    require(not contained(root, TARGET).exists(), "destination must be absent on first application")
    expected[TARGET] = None
    authority(native, root, manifest, session, nonce)
    for relative, value in expected.items():
        if value is not None:
            guard(guard_tool, "record", contained(root, relative), "read")
    journal = {"status": "STARTED", "manifest_sha256": FROZEN_SHA, "session": session, "nonce": nonce, "completed": [], "pending": None,
               "started_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "execution_amendment": manifest.get("execution_amendment")}
    journal_path = output / "completed-prefix-journal.json"
    write_json(journal_path, journal)
    try:
        for entry in (entry for entry in manifest["entries"] if entry["destination"]):
            check_pins(pins)
            unchanged(root, expected)
            authority(native, root, manifest, session, nonce)
            ledgers, unreadable = native.cm.load_ledgers(root)
            require(not unreadable, "unreadable ledger")
            plan = render(native, root, manifest, entry, ledgers)
            dry = run(cli(hub, root, manifest, entry, session, dry=True))
            require(f"WOULD MIGRATE {entry['source_key']} -> v2.16#{plan.new_gid} " in dry.stdout, "unexpected dry-run allocation")
            check_pins(pins)
            unchanged(root, expected)
            record = authority(native, root, manifest, session, nonce)
            record_path = record.record_path
            record_digest = record.loaded_sha256
            require(sha(record_path.read_bytes()) == record_digest, "record changed after native verification")
            for relative in (plan.source.rel, TARGET):
                path = contained(root, relative)
                if expected[relative] is not None:
                    guard(guard_tool, "check", path)
                else:
                    require(not path.exists(), "new destination appeared before native write")
            check_pins(pins)
            unchanged(root, expected)
            require(sha(record_path.read_bytes()) == record_digest, "record changed before native write")
            journal["pending"] = {"ordinal": entry["ordinal"], "source_key": entry["source_key"], "destination_id": plan.new_gid,
                                  "before": fingerprints(root, expected), "record_sha256": record_digest,
                                  "expected_after": {plan.source.rel: sha(plan.source_after), TARGET: sha(plan.target_after)}}
            write_json(journal_path, journal)
            actual = run(cli(hub, root, manifest, entry, session, dry=False))
            require(f"MIGRATED {entry['source_key']} -> v2.16#{plan.new_gid} " in actual.stdout, "unexpected native write result")
            expected[plan.source.rel] = plan.source_after.encode("utf-8")
            expected[TARGET] = plan.target_after.encode("utf-8")
            unchanged(root, expected)
            check_pins(pins)
            require(sha(record_path.read_bytes()) == record_digest, "record changed during native write")
            authority(native, root, manifest, session, nonce)
            for relative in (plan.source.rel, TARGET):
                guard(guard_tool, "record", contained(root, relative), "write")
            journal["completed"].append({"ordinal": entry["ordinal"], "source_key": entry["source_key"], "destination_id": plan.new_gid,
                                         "after": fingerprints(root, expected)})
            journal["pending"] = None
            write_json(journal_path, journal)
            if len(journal["completed"]) % 25 == 0:
                print(json.dumps({"completed": len(journal["completed"]), "total": 245}), flush=True)
        require(len(journal["completed"]) == 245, "incomplete native prefix")
        require(sha(expected[TARGET].decode("utf-8")) == manifest["native_preflight"]["rendered_target_sha256_utf8"], "final target differs from frozen native rendering")
        journal["status"] = "COMPLETE_CARRIES_ONLY"
    except BaseException as error:
        journal.update(status="STOPPED_REVIEW_REQUIRED", error=type(error).__name__ + ": " + str(error), post=fingerprints(root, expected))
        write_json(journal_path, journal)
        raise
    write_json(journal_path, journal)
    return journal


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--hub-scripts", type=Path, required=True)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--manifest-sha256")
    parser.add_argument("--session")
    parser.add_argument("--nonce")
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--execution-date", required=True, help="actual current host date; frozen proposal stays unchanged")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    hub = args.hub_scripts.resolve()
    require(root == Path("C:/nx-close").resolve() and not hub.is_relative_to(root), "wrong execution worktree or helper location")
    raw = (root / MANIFEST).read_bytes()
    require(sha(raw) == FROZEN_SHA, "manifest is not the exact frozen proposal")
    require(not args.apply or args.manifest_sha256 == FROZEN_SHA, "--apply requires the exact --manifest-sha256")
    require(not args.apply or (args.session and args.session != "auto" and args.nonce), "--apply requires explicit session and nonce")
    manifest = json.loads(raw)
    frozen_hashes = manifest["native_preflight"]["helper_sha256"]
    hashes = dict(RUNTIME_PINNED)
    require(set(hashes) == {name + ".py" for name in MODULES}, "qualified runtime amendment is not finalized")
    require(set(frozen_hashes) == {name + ".py" for name in MODULES} and all(frozen_hashes.get(name) == value for name, value in PINNED.items()), "unqualified native source hashes")
    validator = root / ".nexus-hub/validate-carry-forward-manifest.py"
    guard_tool = Path.home() / ".agents/skills/user-edit-preservation/scripts/edit_guard.py"
    pins = {hub / name: value for name, value in hashes.items()}
    pins.update({root / MANIFEST: FROZEN_SHA, validator: manifest["native_preflight"]["validation_helper_sha256"],
                 Path(__file__).resolve(): sha(Path(__file__).read_bytes())})
    pins.update({contained(root, item["path"]): item["sha256"] for item in manifest["inputs"]})
    if args.apply:
        pins[guard_tool] = sha(guard_tool.read_bytes())
    check_pins(pins)
    result = run([sys.executable, "-I", str(validator), "--root", str(root), "--hub-scripts", str(hub), "--render-only"], timeout=300)
    validation = json.loads(result.stdout)
    require(validation["status"] == "PASS" and not validation["input_hash_drift"], "existing native preflight did not pass")
    require(validation["rendered_target_sha256_utf8"] == manifest["native_preflight"]["rendered_target_sha256_utf8"], "runtime amendment changed approved rendering")
    carries = [entry for entry in manifest["entries"] if entry["destination"]]
    require(len(validation["rendered"]) == len(carries) == 245, "approved rendering count changed")
    for entry, rendered in zip(carries, validation["rendered"]):
        approved = entry["destination"]
        require(rendered["source_key"] == entry["source_key"] and rendered["id"] == approved["id"]
                and rendered["title"] == approved["title"] and rendered["body"] == approved["proposed_body"],
                "runtime amendment changed frozen destination: " + entry["source_key"])
    check_pins(pins)
    native = native_modules(hub, hashes)
    manifest = execution_manifest(native, root, manifest, args.execution_date)
    output = args.output_dir.resolve() if args.output_dir else Path(tempfile.mkdtemp(prefix="nexus-carry-forward-"))
    require(not output.is_relative_to(root) and not output.is_relative_to(hub), "private output must be outside both repositories")
    if args.output_dir:
        output.mkdir(mode=0o700)
    os.chmod(output, 0o700)
    print(json.dumps({"private_output": str(output), "manifest_sha256": FROZEN_SHA}), flush=True)
    frozen_sources(root, manifest)
    closure_previews(native, root, manifest, output)
    frozen_sources(root, manifest)
    check_pins(pins)
    journal = apply_carries(native, root, hub, manifest, args.session, args.nonce, pins, output, guard_tool) if args.apply else None
    print(json.dumps({"status": "PASS", "applied_carries": len(journal["completed"]) if journal else 0,
                      "closure_previews": 14, "closures_applied": 0, "journal": str(output / "completed-prefix-journal.json") if journal else None,
                      "authority": "verified native record" if journal else "not evaluated; repository read-only"}))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, subprocess.SubprocessError) as error:
        print(json.dumps({"status": "FAIL", "error": str(error)}))
        sys.exit(1)
