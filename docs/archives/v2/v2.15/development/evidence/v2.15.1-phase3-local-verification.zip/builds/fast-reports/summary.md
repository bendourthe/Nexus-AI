# fast

Status: PASS

| Group | Status | Duration ms |
| --- | --- | ---: |
| npm run lint | PASS | 11727 |
| node bin/nexus-check.mjs --baseline configs/nexus-check-baseline.json | PASS | 1938 |
| node scripts/check-command-parity.mjs | PASS | 96 |
| node scripts/check-release-assets.mjs | PASS | 51 |
| node scripts/check-docs-layout.mjs | PASS | 50 |
