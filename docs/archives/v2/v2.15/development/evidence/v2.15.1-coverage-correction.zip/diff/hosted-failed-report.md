# Diff Coverage
## Diff: origin/main...HEAD, staged and unstaged changes

- core/generations/ImageEditRecipeStore&#46;ts (0.0%): Missing lines 70-72,74,76-79,84-89,94-102,104-109
- core/generations/StudioSessionStore&#46;ts (0.0%): Missing lines 563,573,575,578-580,582,584-586,589,591,593-594,596-597,599
- modules/chat/storage/ChatExplorerStore&#46;ts (100%)
- modules/coding/autonomy/AskInbox&#46;ts (65.9%): Missing lines 244-247,287,306-308,310-314,327
- modules/coding/runtime/headlessTools&#46;ts (100%)
- modules/coding/runtime/outputBudget&#46;ts (100%)

## Summary

- **Total**: 101 lines
- **Missing**: 60 lines
- **Coverage**: 40%



## core/generations/ImageEditRecipeStore&#46;ts

```
   66   }
   67 
   68   /** Called only by the trusted approval owner, not an agent request handler. */
   69   captureCheckpoint(identityInput: ImageEditIdentity, metadata: Omit<ImageEditCheckpoint, "recipe">): ImageEditCheckpoint {
!  70     const identity = this.identity(identityInput);
!  71     if ([metadata.id, metadata.requestId, metadata.approvalId, metadata.callerId, metadata.runId]
!  72       .some((value) => typeof value !== "string" || !value || value.length > 256)
   73       || !Number.isSafeInteger(metadata.createdAt) || metadata.createdAt < 0) {
!  74       throw new ImageEditError("INVALID_RECIPE", "Invalid checkpoint approval metadata.");
   75     }
!  76     return this.storage(() => this.sessions.withImageRecipe(identity.studioSessionId, identity.studioTurnId, (scope) => {
!  77       const source = this.source(scope.turn, identity);
!  78       const recipe = this.existing(scope.recipeJson, identity, source, scope.storedRevision, scope.storedSourceSha256);
!  79       return scope.checkpoint({ ...metadata, recipe });
   80     }));
   81   }
   82 
   83   listCheckpoints(identityInput: ImageEditIdentity, access: ImageEditAccess, beforeId?: string): ImageEditCheckpointSummary[] {
!  84     const identity = this.identity(identityInput);
!  85     this.checkAccess(access, identity);
!  86     return this.storage(() => this.sessions.withImageRecipe(identity.studioSessionId, identity.studioTurnId, (scope) => {
!  87       this.source(scope.turn, identity);
!  88       this.checkAccess(access, identity);
!  89       return scope.checkpoints(beforeId);
   90     }));
   91   }
   92 
   93   restoreCheckpoint(identityInput: ImageEditIdentity, access: ImageEditAccess, checkpointId: string, expectedRevision: number): ImageEditRecipe {
!  94     const identity = this.identity(identityInput);
!  95     this.checkAccess(access, identity);
!  96     return this.storage(() => this.sessions.withImageRecipe(identity.studioSessionId, identity.studioTurnId, (scope) => {
!  97       const source = this.source(scope.turn, identity);
!  98       const previous = this.existing(scope.recipeJson, identity, source, scope.storedRevision, scope.storedSourceSha256);
!  99       if (previous.revision !== expectedRevision) throw new ImageEditError("REVISION_CONFLICT", "The image recipe revision is stale.");
! 100       const checkpoint = scope.findCheckpoint(checkpointId);
! 101       if (!checkpoint) throw new ImageEditError("FORBIDDEN", "No recovery checkpoint matches this image.");
! 102       const saved = this.existing(JSON.stringify(checkpoint.recipe), identity, source,
  103         checkpoint.recipe.revision, checkpoint.recipe.identity.sourceSha256);
! 104       const next = parseImageEditRecipe({ ...saved, revision: previous.revision + 1 });
! 105       this.checkAccess(access, identity);
! 106       scope.commit(next, expectedRevision);
! 107       this.source(scope.turn, identity);
! 108       this.checkAccess(access, identity);
! 109       return next;
  110     }));
  111   }
  112 
  113   /**
```


---



## core/generations/StudioSessionStore&#46;ts

```
  559         turn,
  560         recipeJson: stored?.recipe_json ?? null,
  561         storedRevision: stored?.revision ?? 0,
  562         storedSourceSha256: stored?.source_sha256 ?? null,
! 563         checkpoints: (beforeId) => this.db.prepare(`
  564           SELECT id, json_extract(checkpoint_json, '$.createdAt') AS createdAt,
  565             json_extract(checkpoint_json, '$.callerId') AS callerId, json_extract(checkpoint_json, '$.runId') AS runId,
  566             json_extract(checkpoint_json, '$.recipe.revision') AS revision, json_extract(checkpoint_json, '$.recipe.cursor') AS cursor,
  567             json_array_length(checkpoint_json, '$.recipe.commands') AS commands
```


---


```
  569             AND (? IS NULL OR rowid < (SELECT rowid FROM studio_image_edit_checkpoints WHERE id = ? AND turn_id = ? AND session_id = ?))
  570           ORDER BY rowid DESC LIMIT 50
  571         `).all(turnId, sessionId, beforeId ?? null, beforeId ?? null, turnId, sessionId) as ImageEditCheckpointSummary[],
  572         findCheckpoint: (id) => {
! 573           const checkpoint = this.db.prepare("SELECT checkpoint_json FROM studio_image_edit_checkpoints WHERE id = ? AND turn_id = ? AND session_id = ?")
  574             .get(id, turnId, sessionId) as { checkpoint_json: string } | undefined;
! 575           return checkpoint ? JSON.parse(checkpoint.checkpoint_json) as ImageEditCheckpoint : null;
  576         },
  577         checkpoint: (input) => {
! 578           const recipe = parseImageEditRecipe(input.recipe);
! 579           if (recipe.identity.studioSessionId !== sessionId || recipe.identity.studioTurnId !== turnId) {
! 580             throw new ImageEditError("REVISION_CONFLICT", "The recovery checkpoint does not match the current image.");
  581           }
! 582           const existing = this.db.prepare("SELECT checkpoint_json FROM studio_image_edit_checkpoints WHERE id = ?")
  583             .get(input.id) as { checkpoint_json: string } | undefined;
! 584           if (existing) {
! 585             const previous = JSON.parse(existing.checkpoint_json) as ImageEditCheckpoint;
! 586             if (previous.requestId !== input.requestId || previous.approvalId !== input.approvalId
  587               || previous.callerId !== input.callerId || previous.runId !== input.runId
  588               || JSON.stringify(previous.recipe.identity) !== JSON.stringify(recipe.identity)) {
! 589               throw new ImageEditError("FORBIDDEN", "The checkpoint belongs to another approval.");
  590             }
! 591             return previous;
  592           }
! 593           if (recipe.revision !== (stored?.revision ?? 0)) {
! 594             throw new ImageEditError("REVISION_CONFLICT", "The recovery checkpoint does not match the current image.");
  595           }
! 596           const checkpoint = { ...input, recipe };
! 597           this.db.prepare("INSERT INTO studio_image_edit_checkpoints (id, turn_id, session_id, checkpoint_json) VALUES (?, ?, ?, ?)")
  598             .run(input.id, turnId, sessionId, JSON.stringify(checkpoint));
! 599           return checkpoint;
  600         },
  601         commit: (input, expectedRevision) => {
  602           const recipe = parseImageEditRecipe(input);
  603           if (committed || !Number.isSafeInteger(expectedRevision)
```


---



## modules/coding/autonomy/AskInbox&#46;ts

```
  240     if (prepare) this._preparations.set(ask.id, prepare);
  241     try {
  242       await this.persist();
  243     } catch (error) {
! 244       this._waiters.delete(ask.id);
! 245       this._preparations.delete(ask.id);
! 246       this._items = this._items.filter((item) => item.id !== ask.id);
! 247       throw error;
  248     }
  249     return decision;
  250   }
```


---


```
  283         decidedAt: now,
  284         decisionReason: replay.reason,
  285       };
  286       this._waiters.delete(id);
! 287       this._preparations.delete(id);
  288       waiter("denied");
  289       await this.persist();
  290       return { ok: false, reason: replay.reason, replay, executed: false };
  291     }
```


---


```
  302         // Keep the visible/live item pending until the decision has been saved.
  303         await this._store.save(this._items.map((item) => item.id === id ? approved : item));
  304         if (!valid()) {
  305           // A restore, denial or expiry during save must never activate a grant.
! 306           const current = this._items.findIndex((item) => item.id === id);
! 307           if (current >= 0 && this._items[current]!.state === "pending") {
! 308             this._items[current] = { ...ask, state: "denied", decidedAt: this._now(), decisionReason: "approval invalidated while saving" };
  309           }
! 310           this._waiters.delete(id);
! 311           this._preparations.delete(id);
! 312           waiter("denied");
! 313           await this._store.save(this._items);
! 314           return false;
  315         }
  316         this._items = this._items.map((item) => item.id === id ? approved : item);
  317         this._waiters.delete(id);
  318         this._preparations.delete(id);
```


---


```
  323       const saved = await next;
  324       return { ok: saved, reason: saved ? replay.reason : "Approval was invalidated before activation.", replay, executed: false };
  325     } catch {
  326       // Checkpoint/save failure leaves a pending retry, with no live grant.
! 327       return { ok: false, reason: "Approval could not be saved. No access was granted. Retry approval.", replay, executed: false };
  328     } finally {
  329       this._approving.delete(id);
  330     }
  331   }
```


---


