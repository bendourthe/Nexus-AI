# Diff Coverage
## Diff: origin/main...HEAD, staged and unstaged changes

- core/generations/ImageEditRecipeStore&#46;ts (100%)
- core/generations/StudioSessionStore&#46;ts (88.2%): Missing lines 580,594
- modules/chat/storage/ChatExplorerStore&#46;ts (100%)
- modules/coding/autonomy/AskInbox&#46;ts (65.9%): Missing lines 244-247,287,306-308,310-314,327
- modules/coding/runtime/headlessTools&#46;ts (100%)
- modules/coding/runtime/outputBudget&#46;ts (100%)

## Summary

- **Total**: 101 lines
- **Missing**: 16 lines
- **Coverage**: 84%



## core/generations/StudioSessionStore&#46;ts

```
  576         },
  577         checkpoint: (input) => {
  578           const recipe = parseImageEditRecipe(input.recipe);
  579           if (recipe.identity.studioSessionId !== sessionId || recipe.identity.studioTurnId !== turnId) {
! 580             throw new ImageEditError("REVISION_CONFLICT", "The recovery checkpoint does not match the current image.");
  581           }
  582           const existing = this.db.prepare("SELECT checkpoint_json FROM studio_image_edit_checkpoints WHERE id = ?")
  583             .get(input.id) as { checkpoint_json: string } | undefined;
  584           if (existing) {
```


---


```
  590             }
  591             return previous;
  592           }
  593           if (recipe.revision !== (stored?.revision ?? 0)) {
! 594             throw new ImageEditError("REVISION_CONFLICT", "The recovery checkpoint does not match the current image.");
  595           }
  596           const checkpoint = { ...input, recipe };
  597           this.db.prepare("INSERT INTO studio_image_edit_checkpoints (id, turn_id, session_id, checkpoint_json) VALUES (?, ?, ?, ?)")
  598             .run(input.id, turnId, sessionId, JSON.stringify(checkpoint));
```


---



## modules/coding/autonomy/AskInbox&#46;ts

```
  240     if (prepare) this._preparations.set(ask.id, prepare);
  241     try {
  242       await this.persist();
  243     } catch (error) {
! 244       this._waiters.delete(ask.id);
! 245       this._preparations.delete(ask.id);
! 246       this._items = this._items.filter((item) => item.id !== ask.id);
! 247       throw error;
  248     }
  249     return decision;
  250   }
```


---


```
  283         decidedAt: now,
  284         decisionReason: replay.reason,
  285       };
  286       this._waiters.delete(id);
! 287       this._preparations.delete(id);
  288       waiter("denied");
  289       await this.persist();
  290       return { ok: false, reason: replay.reason, replay, executed: false };
  291     }
```


---


```
  302         // Keep the visible/live item pending until the decision has been saved.
  303         await this._store.save(this._items.map((item) => item.id === id ? approved : item));
  304         if (!valid()) {
  305           // A restore, denial or expiry during save must never activate a grant.
! 306           const current = this._items.findIndex((item) => item.id === id);
! 307           if (current >= 0 && this._items[current]!.state === "pending") {
! 308             this._items[current] = { ...ask, state: "denied", decidedAt: this._now(), decisionReason: "approval invalidated while saving" };
  309           }
! 310           this._waiters.delete(id);
! 311           this._preparations.delete(id);
! 312           waiter("denied");
! 313           await this._store.save(this._items);
! 314           return false;
  315         }
  316         this._items = this._items.map((item) => item.id === id ? approved : item);
  317         this._waiters.delete(id);
  318         this._preparations.delete(id);
```


---


```
  323       const saved = await next;
  324       return { ok: saved, reason: saved ? replay.reason : "Approval was invalidated before activation.", replay, executed: false };
  325     } catch {
  326       // Checkpoint/save failure leaves a pending retry, with no live grant.
! 327       return { ok: false, reason: "Approval could not be saved. No access was granted. Retry approval.", replay, executed: false };
  328     } finally {
  329       this._approving.delete(id);
  330     }
  331   }
```


---


