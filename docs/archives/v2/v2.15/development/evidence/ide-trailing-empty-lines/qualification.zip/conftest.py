from pathlib import Path
import importlib
import sys

SCRIPTS = Path(__file__).resolve().parent / "scripts"
sys.path.insert(0, str(SCRIPTS))
# Pin the imported fixture helpers to the same seven modules used by child CLIs.
for name in ("repo_host", "approval_binding", "approval_page", "check_plan_completion", "completion_minor", "minor_close", "cleanup_merged"):
    module = importlib.import_module(name)
    assert Path(module.__file__).resolve().parent == SCRIPTS.resolve(), (name, module.__file__)
