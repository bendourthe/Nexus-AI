from pathlib import Path
import datetime as dt,json
from test_one_plan_envelope_private import approval,repo,ck,SESSION,binding,_isolated_git_config,_no_transport_overrides,PLAN


def test_real_isolated_two_lf_capture_create_preserves_whole_origin_and_rejects_replay(approval):
    repo,spec,line,log=approval
    message='# Context from my IDE setup:\n\n## Open tabs:\n- DEVLOG.md: docs/DEVLOG.md\n\n## My request:\n'+line+'\n\n'
    repo.capture(SESSION,message)
    event=binding.capture_events(repo.runs,SESSION)[-1]
    rows=[{'type':'session_meta','payload':{'id':SESSION,'originator':'codex_vscode','source':'vscode'}},{'type':'turn_context','payload':{'cwd':str(repo.work),'approval_policy':'never','sandbox_policy':{'type':'danger-full-access'}}},{'type':'event_msg','timestamp':dt.datetime.fromtimestamp(event['at'],dt.UTC).isoformat(),'payload':{'type':'user_message','message':message}}]
    log.write_text(''.join(json.dumps(row)+'\n' for row in rows),encoding='utf-8')
    ctx=ck.Context(str(repo.work/PLAN),ck.Budget(60));key=ck._round_key(ctx)
    pending=binding.pending_path(repo.runs,key);pending_raw=pending.read_bytes();frozen=json.loads(pending_raw)
    result=repo.run('record','create',PLAN,'--session',SESSION,'--approvals',str(spec),'--approval-transcript',str(log))
    if result.returncode:
        assert not ctx.record_path().exists()
        assert pending.read_bytes()==pending_raw and binding.event_available(repo.runs,SESSION,event)
    assert result.returncode==0,result.stdout+result.stderr
    record=ck.load_record(ctx,SESSION).record
    assert record is not None and record['start_head']==repo.head()
    assert record['approvals']['authorization_context']['prompt_sha256']==event['prompt']==binding.digest(message)
    assert event['prompt']!=binding.digest(line)
    assert record['approvals']['authorization_context']['requested_line']==line
    assert record['approvals']['page_sha256']==ck.hashlib.sha256(binding.canonical(frozen['page'])).hexdigest()
    assert not binding.event_available(repo.runs,SESSION,event)
    before=ctx.record_path().read_bytes()
    again=repo.run('record','create',PLAN,'--session',SESSION,'--approvals',str(spec),'--approval-transcript',str(log))
    assert again.returncode!=0 and 'code-used' in again.stdout
    assert ctx.record_path().read_bytes()==before
