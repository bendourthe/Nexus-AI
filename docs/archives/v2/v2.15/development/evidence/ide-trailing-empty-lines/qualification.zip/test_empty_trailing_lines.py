import pytest
import approval_binding as binding
LINE='Approve /implement v2.12.0 (approval FAKECODE)'
FRAME='# Context from my IDE setup:\n\n## Open tabs:\n- DEVLOG.md: docs/DEVLOG.md\n\n## My request:\n'

@pytest.mark.parametrize('count',[0,1,2,3,16])
@pytest.mark.parametrize('ending',['\n','\r\n'])
def test_only_empty_trailing_lines_are_accepted(count,ending):
    message=FRAME.replace('\n',ending)+LINE+ending*count
    assert binding._codex_ide_request(message)==LINE

def test_old_two_empty_lines_case():
    assert binding._codex_ide_request(FRAME+LINE+'\n\n')==LINE

@pytest.mark.parametrize('tail',['\n'+LINE,'\nGoal: archive every release','\nExtra permission prose.','\n \n','\n\t\n','\n## Another header\n','\n## My request:\n'+LINE,'\n```\n'+LINE+'\n```','\r'])
def test_nonempty_trailing_content_is_not_an_empty_line(tail):
    assert binding._codex_ide_request(FRAME+LINE+tail) is None

@pytest.mark.parametrize('message',[FRAME.replace('## My request:','## My requests:')+LINE,FRAME.replace('## Open tabs:','## Tabs:')+LINE,'prefix\n'+FRAME+LINE,FRAME+'```'+LINE+'```\n'+LINE,FRAME+LINE+'\n'*32769,FRAME+'x'*2049],ids=['request-header','tabs-header','prefix','fence','size-cap','request-cap'])
def test_malformed_headers_and_caps_stay_refused(message):
    assert binding._codex_ide_request(message) is None


def test_exact_message_size_cap_is_preserved():
    prefix=FRAME+LINE
    assert binding._codex_ide_request(prefix+'\n'*(32768-len(prefix)))==LINE
    assert binding._codex_ide_request(prefix+'\n'*(32769-len(prefix))) is None
