from pathlib import Path
import hashlib,json,subprocess,sys,time,xml.etree.ElementTree as ET
w=Path(__file__).resolve().parent;freeze=json.loads((w/'source-freeze-v2.json').read_text())
def audit():return {n:hashlib.sha256((w/'scripts'/n).read_bytes()).hexdigest() for n in freeze['sha256']}
if audit()!=freeze['sha256']:raise RuntimeError('private source drift')
args=[sys.executable,'-B','-m','pytest','-q',*freeze['test_sha256'],'--tb=short','--junitxml',str(w/'qualification-final.junit.xml')]
start=time.monotonic();r=subprocess.run(args,cwd=w,capture_output=True,text=True)
(w/'qualification-final.log').write_text(r.stdout+r.stderr,encoding='utf-8')
cases=len(ET.parse(w/'qualification-final.junit.xml').getroot().findall('.//testcase'))
value={'command':args,'cwd':str(w),'exit_code':r.returncode,'cases':cases,'elapsed_seconds':round(time.monotonic()-start,3),'before':freeze['sha256'],'after':audit(),'private_only':True,'actual_rounds_records_captures_touched':False}
(w/'qualification-final.json').write_text(json.dumps(value,indent=2),encoding='utf-8')
print(json.dumps({'exit_code':r.returncode,'cases':cases,'elapsed_seconds':value['elapsed_seconds'],'source_stable':value['before']==value['after']}))
if r.returncode:print((r.stdout+r.stderr)[-2500:])
raise SystemExit(r.returncode or (0 if value['before']==value['after'] else 1))
