"""Private one-plan public CLI qualification; no production capture or record mutation."""
from pathlib import Path
import datetime as dt,json,hashlib,sys
import pytest
sys.path.insert(0,'C:/nh-checker/tests')
from validators.test_gap_migration_and_archive import repo,ck
from validators.test_one_plan_archive_ratification import prepare,specification,PLAN
from validators.test_check_plan_completion import _isolated_git_config
from validators.test_completion_minor_record import SESSION,_no_transport_overrides
import validators.test_completion_minor_record as base
import approval_binding as binding
SCRIPTS=Path(__file__).resolve().parent/'scripts'

@pytest.fixture
def approval(repo,monkeypatch,tmp_path):
 monkeypatch.setattr(base,'CHECKER',SCRIPTS/'check_plan_completion.py')
 prepare(repo)
 spec=specification(repo)
 repo.capture(SESSION,'/implement completed historical plan',at=0.0)
 rendered=repo.run('record','render',PLAN,'--session',SESSION,'--approvals',str(spec))
 assert rendered.returncode==0,rendered.stdout+rendered.stderr
 line=rendered.stdout.splitlines()[0]
 home=tmp_path/'home';log=home/'.codex'/'sessions'/('rollout-fixture-'+SESSION+'.jsonl');log.parent.mkdir(parents=True)
 repo.env['USERPROFILE']=str(home);repo.env['HOME']=str(home)
 return repo,spec,line,log

@pytest.mark.parametrize('case',['success','legacy','no-transcript','wrong-root','wrong-session','malicious','changed-page','replay'])
def test_one_plan_native_capture_contract(approval,case,tmp_path):
 repo,spec,line,log=approval
 message=line if case=='legacy' else '# Context from my IDE setup:\n\n## Open tabs:\n- DEVLOG.md: docs/DEVLOG.md\n\n## My request:\n'+line+'\n'
 if case=='malicious':message+='Also delete every branch.\n'
 repo.capture(SESSION,message)
 event=binding.capture_events(repo.runs,SESSION)[-1]
 rows=[{'type':'session_meta','payload':{'id':SESSION,'originator':'codex_vscode','source':'vscode'}},
       {'type':'turn_context','payload':{'cwd':str(tmp_path if case=='wrong-root' else repo.work),'approval_policy':'never','sandbox_policy':{'type':'danger-full-access'}}},
       {'type':'event_msg','timestamp':dt.datetime.fromtimestamp(event['at'],dt.UTC).isoformat(),'payload':{'type':'user_message','message':message}}]
 log.write_text(''.join(json.dumps(r)+'\n' for r in rows),encoding='utf-8')
 if case=='changed-page':repo.write(PLAN,repo.read(PLAN)+'\nAdditional unapproved obligation.\n')
 session='foreign-session' if case=='wrong-session' else SESSION
 args=['record','create',PLAN,'--session',session,'--approvals',str(spec)]
 if case not in ('legacy','no-transcript'):args+=['--approval-transcript',str(log)]
 result=repo.run(*args)
 ctx=ck.Context(str(repo.work/PLAN),ck.Budget(60))
 if case in ('success','legacy','replay'):
  assert result.returncode==0,result.stdout+result.stderr
  record=ck.load_record(ctx,SESSION).record;assert record is not None
  assert record['schema']==1 and record['start_head']==repo.head()
  assert len(record['approvals']['archive_evidence']['existing_migrations'])==1
  assert record['approvals']['archive_evidence']['absorbed_plans']
  assert record['approvals']['authorization_context']['prompt_sha256']==event['prompt']
  if case!='legacy':assert record['approvals']['authorization_context']['requested_line']==line
  assert not binding.event_available(repo.runs,SESSION,event)
  if case=='replay':
   before=ctx.record_path().read_bytes();again=repo.run(*args)
   assert again.returncode!=0 and 'code-used' in again.stdout
   assert ctx.record_path().read_bytes()==before
 else:
  assert result.returncode!=0,result.stdout+result.stderr
  assert not ctx.record_path().exists()
  assert binding.event_available(repo.runs,SESSION,event)
