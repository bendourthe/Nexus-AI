"""Private compatibility regressions; all transcripts, runs and keys are fixtures."""
from __future__ import annotations
import copy,datetime,hashlib,json
from pathlib import Path
import pytest
from .test_approval_flow_continuation import captures,approved_record,render,SECRET,SESSION
import approval_binding as binding
import check_plan_completion as checker
FIXTURES=Path(__file__).resolve().parents[1]/'fixtures/response_item'

def response(text,role='user'):
 return {'type':'response_item','payload':{'type':'message','role':role,'content':[{'type':'input_text','text':text}]}}

@pytest.fixture
def transcript(captures,tmp_path,monkeypatch):
 runs,capture=captures;home=tmp_path/'fake-home';cwd=tmp_path/'repo';cwd.mkdir();monkeypatch.setattr(Path,'home',classmethod(lambda cls:home))
 text='Use the existing narrowly approved fixture work.';capture(text);event=binding.capture_events(runs,SESSION)[-1]
 at=datetime.datetime.fromtimestamp(event['at'],datetime.timezone.utc).isoformat()
 log=home/'.codex/sessions/2026/10/22'/f'rollout-fixture-{SESSION}.jsonl';log.parent.mkdir(parents=True)
 rows=[{'type':'session_meta','payload':{'id':SESSION,'originator':'codex_vscode','source':'vscode'}},{'type':'turn_context','payload':{'cwd':str(cwd),'approval_policy':'never','sandbox_policy':{'type':'danger-full-access'}}},{**response(text),'timestamp':at}]
 def write():log.write_text(''.join(json.dumps(row)+'\n' for row in rows),encoding='utf-8')
 write();return {'runs':runs,'capture':capture,'home':home,'cwd':cwd,'log':log,'rows':rows,'write':write,'event':event,'text':text}

def lookup(t):return binding.codex_transcript_context(t['log'],SESSION,t['event'],{str(t['cwd'].resolve())})

def test_synthetic975_whole_message_digest_and_fake_record_unchanged(transcript):
 t=transcript;text=(FIXTURES/'synthetic-owner-instruction.txt').read_text();assert len(text.encode())==975
 assert hashlib.sha256(text.encode()).hexdigest()=='55bb862df72acfb334347b754be05b2d0c59a1a95631b4272c978930b4392e96'
 assert binding.digest(text)=='2e8d480703ca68db1bfacc6ec4358b265952e7211d5ce79cf321d70cada90f96'
 t['event']={'prompt':binding.digest(text),'at':1792404000.0};t['rows'][2]={**response(text),'timestamp':'2026-10-19T10:00:00Z'};t['write']()
 record=approved_record();before=copy.deepcopy(record);sign=checker._sign(record,SECRET)
 result=lookup(t);assert result['permission_mode']=='bypassPermissions' and result['prompt_sha256']==t['event']['prompt']
 assert record==before and checker._sign(record,SECRET)==sign

@pytest.mark.parametrize('role',['assistant','tool','developer','system',None,'USER'])
def test_nonuser_roles_refused(transcript,role):
 t=transcript;t['rows'][2]['payload']['role']=role;t['write']()
 with pytest.raises(ValueError,match='not corroborated'):lookup(t)

@pytest.mark.parametrize('content',[None,[],{},'plain string',[{'type':'input_text','text':'x'},{'type':'input_text','text':'x'}],[{'type':'output_text','text':'x'}],[{'type':'input_text','text':None}],[{'type':'input_text','text':123}],[{'type':'input_text','text':'x','extra':'unsupported'}],[{'type':'input_image','text':'x'}],[{'text':'x'}],[None],[{'type':'input_text','text':'x'},{'type':'input_image','image_url':'synthetic'}],{'type':'input_text','text':'x'}])
def test_unobserved_content_shapes_refused(transcript,content):
 t=transcript;content=copy.deepcopy(content)
 if isinstance(content,str):content=t['text']
 parts=content if isinstance(content,list) else [content]
 for part in parts:
  if isinstance(part,dict) and part.get('text')=='x':part['text']=t['text']
 t['rows'][2]['payload']['content']=content;t['write']()
 with pytest.raises(ValueError,match='not corroborated'):lookup(t)

@pytest.mark.parametrize('outer,inner',[('event_msg','message'),('tool_result','message'),('response_item','function_call'),('response_item','function_call_output')])
def test_other_row_kinds_refused(transcript,outer,inner):
 t=transcript;t['rows'][2]['type']=outer;t['rows'][2]['payload']['type']=inner;t['write']()
 with pytest.raises(ValueError,match='not corroborated'):lookup(t)

def test_legacy_event_format_still_passes(transcript):
 t=transcript;t['rows'][2]={'type':'event_msg','timestamp':t['rows'][2]['timestamp'],'payload':{'type':'user_message','message':t['text']}};t['write']();assert lookup(t)['permission_mode']=='bypassPermissions'

@pytest.mark.parametrize('bad',['session','origin','source','timestamp','initial_mode','initial_cwd','latest_mode','latest_cwd','wrong_digest'])
def test_existing_context_boundaries_preserved(transcript,bad):
 t=transcript
 if bad=='session':t['rows'][0]['payload']['id']='foreign-session'
 if bad=='origin':t['rows'][0]['payload']['originator']='foreign'
 if bad=='source':t['rows'][0]['payload']['source']='cli'
 if bad=='timestamp':t['rows'][2]['timestamp']='2000-01-01T00:00:00Z'
 if bad=='initial_mode':t['rows'][1]['payload']['approval_policy']='on-request'
 if bad=='initial_cwd':t['rows'][1]['payload']['cwd']=str(t['home']/'foreign')
 if bad=='latest_mode':t['rows'].append({'type':'turn_context','payload':{**t['rows'][1]['payload'],'approval_policy':'on-request'}})
 if bad=='latest_cwd':t['rows'].append({'type':'turn_context','payload':{**t['rows'][1]['payload'],'cwd':str(t['home']/'foreign')}})
 if bad=='wrong_digest':t['event']={**t['event'],'prompt':'0'*64}
 t['write']()
 if bad in ['latest_mode','latest_cwd']:assert lookup(t)['permission_mode']=='manual'
 else:
  with pytest.raises(ValueError):lookup(t)

def test_wrong_filename_and_foreign_path_refused(transcript,tmp_path):
 t=transcript
 for log in [tmp_path/'foreign.jsonl',t['log'].with_name('rollout-foreign-session.jsonl')]:
  log.write_bytes(t['log'].read_bytes())
  with pytest.raises(ValueError):binding.codex_transcript_context(log,SESSION,t['event'],{str(t['cwd'].resolve())})

def test_current_mode_is_not_sticky(transcript):
 t=transcript;record=approved_record();record['approvals']['authorization_context']=lookup(t)
 assert binding.current_host_context(t['runs'],record,{str(t['cwd'].resolve())})['permission_mode']=='bypassPermissions'
 t['rows'].append({'type':'turn_context','payload':{**t['rows'][1]['payload'],'sandbox_policy':{'type':'workspace-write'}}});t['write']()
 with pytest.raises(ValueError):binding.current_host_context(t['runs'],record,{str(t['cwd'].resolve())})

def test_synthetic_policy_adoption_preserves_frozen_identity(transcript):
 t=transcript
 record=approved_record();before=copy.deepcopy(record);binding.adopt_policy(t['runs'],record,t['text'],{},t['log'],{str(t['cwd'].resolve())})
 assert record['nonce']==before['nonce'] and record['start_head']==before['start_head'] and record['approvals']['classes']==before['approvals']['classes']
 assert record['approvals']['authorization_context']['origin']=='codex-host-transcript'

@pytest.mark.parametrize('wrapped',[True,False])
@pytest.mark.parametrize('action',['create','answer'])
def test_ide_request_wholemessage_only_and_no_callback_flattening(transcript,wrapped,action):
 t=transcript;pending=binding.render(t['runs'],'fixture',SECRET,action=action,scope='v0.2.0',page={'record_nonce':'synthetic-only','blocker':{'index':0,'category':'no-progress'}},session=SESSION,blocker=0 if action=='answer' else None,allow_short_reply=False);line=pending['paste_lines'][0]
 if wrapped:message=json.dumps({'answer':line,'guidance':'Also copied extra guidance; never extract answer.'})
 else:message='# Context from my IDE setup:\n\n## Open tabs:\n- fixture.md: docs/fixture.md\n\n## My request:\n'+line
 t['capture'](message);event=binding.capture_events(t['runs'],SESSION)[-1];t['rows'][2]={**response(message),'timestamp':datetime.datetime.fromtimestamp(event['at'],datetime.timezone.utc).isoformat()};t['write']()
 kwargs={'action':action,'live_page':pending['page'],'session':SESSION,'required_session':SESSION,'transcript':t['log'],'allowed_cwds':{str(t['cwd'].resolve())}}
 if wrapped or action=='answer':
  with pytest.raises(binding.Refusal,match='approval-not-captured'):binding.consume(t['runs'],'fixture',SECRET,**kwargs)
  assert binding.pending_path(t['runs'],'fixture').exists()
 else:
  consumed,_=binding.consume(t['runs'],'fixture',SECRET,**kwargs);assert consumed['pasted']==line
  with pytest.raises(binding.Refusal,match='code-used'):binding.consume(t['runs'],'fixture',SECRET,**kwargs)

def test_native52_plan_hashes_unchanged():
 hashes=json.loads((FIXTURES/'plan-hashes.json').read_bytes());assert len(hashes)==5
 for rel,wanted in hashes.items():assert checker.plan_hash_text((FIXTURES/'plans'/Path(rel).name).read_text())==wanted
