const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { performance } = require('node:perf_hooks');
const { createRequire } = require('node:module');
const repoRequire = createRequire('C:/nx-close/package.json');
const { JSDOM } = repoRequire('jsdom');
const root = __dirname;
const rows = [];
for (const version of ['3.4.16', '3.4.17']) {
  const createPurify = require(path.join(root, `dompurify-${version}/package/dist/purify.cjs.js`));
  {
    const win = new JSDOM('<!doctype html><body></body>').window;
    const purify = createPurify(win);
    const host = win.document.createElement('div');
    const shadow = host.attachShadow({ mode: 'open' });
    shadow.append(win.document.createTextNode('$'), win.document.createElement('object'), win.document.createTextNode('{probeMarker}'), win.document.createTextNode(' safe text'));
    purify.sanitize(host, { IN_PLACE: true, SAFE_FOR_TEMPLATES: true });
    shadow.normalize();
    const result = { advisory: 'GHSA-cg2g-xh64-v4q7', version, output: shadow.textContent, vulnerableExpressionRetained: shadow.textContent.includes('${probeMarker}'), benignTextRetained: shadow.textContent.includes('safe text') };
    assert.equal(result.vulnerableExpressionRetained, version === '3.4.16');
    assert.equal(result.benignTextRetained, true);
    rows.push(result); win.close();
  }
  for (const mode of ['self', 'parent', 'nextSibling']) {
    const win = new JSDOM('<!doctype html><body><div id="root"><figure><img class="bad" src="a.png"><img id="retained" src="x" onerror="void 0"></figure><p>safe paragraph</p></div></body>').window;
    const purify = createPurify(win);
    const host = win.document.getElementById('root');
    const retained = win.document.getElementById('retained');
    purify.addHook('afterSanitizeAttributes', (node) => {
      if (node.getAttribute?.('class') !== 'bad') return;
      if (mode === 'self') node.remove();
      if (mode === 'parent') node.parentNode.remove();
      if (mode === 'nextSibling') node.nextElementSibling.remove();
    });
    purify.sanitize(host, { IN_PLACE: true });
    const result = { advisory: 'GHSA-mrv2-3pqr-j5jr', version, mode, retainedHandler: retained.getAttribute('onerror'), benignTextRetained: host.textContent.includes('safe paragraph') };
    assert.equal(result.retainedHandler, version === '3.4.16' && mode !== 'self' ? 'void 0' : null);
    assert.equal(result.benignTextRetained, true);
    rows.push(result); win.close();
  }
  {
    const win = new JSDOM('<!doctype html><body></body>').window;
    const purify = createPurify(win);
    const input = '<svg xmlns="http://www.w3.org/2000/svg" width="200" height="60"><a id="q"><animate attributeName="href" values="x;javascript:void(0)" dur="0.01s" fill="freeze"/><text x="10" y="40" font-size="30">safe diagram</text></a></svg>';
    const output = purify.sanitize(input, { PARSER_MEDIA_TYPE: 'application/xhtml+xml', ALLOWED_TAGS: ['svg', 'a', 'animate', 'text'], ALLOWED_ATTR: ['attributeName', 'values', 'dur', 'fill', 'x', 'y', 'font-size', 'id', 'width', 'height'] });
    const control = purify.sanitize(input, { ALLOWED_TAGS: ['svg', 'a', 'animate', 'text'], ALLOWED_ATTR: ['attributename', 'values', 'dur', 'fill', 'x', 'y', 'font-size', 'id', 'width', 'height'] });
    const result = { advisory: 'GHSA-c6gr-qvv4-5v3f', version, output, vulnerableHrefAnimationRetained: /attributeName="href"/.test(output), benignTextRetained: output.includes('safe diagram'), htmlModeVulnerableAttributeRetained: /attributeName="href"/i.test(control) };
    assert.equal(result.vulnerableHrefAnimationRetained, version === '3.4.16');
    assert.equal(result.benignTextRetained, true);
    assert.equal(result.htmlModeVulnerableAttributeRetained, false);
    rows.push(result); win.close();
  }
}
for (const version of ['10.7.3', '10.7.4']) {
  const packageRoot = path.join(root, `ip-address-${version}/package`);
  const { Address6, Address4 } = require(packageRoot);
  const constants = require(path.join(packageRoot, 'dist/v6/constants.js'));
  const timings = [];
  for (const n of [4000, 8000, 16000, 32000]) {
    const input = '%'.repeat(n) + '\n';
    const samples = [];
    for (let i = 0; i < 3; i++) {
      const start = performance.now();
      assert.equal(Address6.isValid(input), false);
      samples.push(performance.now() - start);
    }
    timings.push({ length: input.length, milliseconds: samples, medianMilliseconds: [...samples].sort((a,b) => a-b)[1] });
  }
  // The exported legacy expression is instrumented only for this call. This
  // records whether the real constructor still reaches the dangerous regex;
  // measured performance remains descriptive and has no pass/fail wall limit.
  let legacyZoneRegexCalls = 0;
  const originalExec = constants.RE_ZONE_STRING.exec;
  constants.RE_ZONE_STRING.exec = function(input) { legacyZoneRegexCalls++; return originalExec.call(this, input); };
  try { assert.equal(Address6.isValid('%'.repeat(100) + '\n'), false); }
  finally { constants.RE_ZONE_STRING.exec = originalExec; }
  assert.equal(legacyZoneRegexCalls > 0, version === '10.7.3');
  const scoped = new Address6('fe80::1%eth0');
  const controls = { ipv6: Address6.isValid('2001:db8::1'), scoped: scoped.correctForm(), zone: scoped.zone, ipv4: Address4.isValid('192.0.2.1'), ordinaryInvalid: Address6.isValid('not-an-address'), percentWithoutNewline: Address6.isValid('%'.repeat(32000)) };
  assert.deepEqual(controls, { ipv6: true, scoped: 'fe80::1', zone: '%eth0', ipv4: true, ordinaryInvalid: false, percentWithoutNewline: false });
  rows.push({ advisory: 'GHSA-rxp7-6hxx-x8q5', version, legacyZoneRegexCalls, timings, controls });
}
const report = { node: process.version, jsdom: repoRequire('jsdom/package.json').version, executablePayloadEvaluation: false, timingThresholdGate: false, rows };
fs.writeFileSync(path.join(root, 'advisory-results.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
