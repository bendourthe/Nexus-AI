import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { sanitizeArtifactHtml } from 'file:///C:/nx-close/desktop/src/shared/security/sanitizeArtifact.ts';
import { sanitizeSvg } from 'file:///C:/nx-close/desktop/src/shared/security/sanitizeSvg.ts';
import { renderMarkdown } from 'file:///C:/nx-close/modules/coding/utils/MarkdownRenderer.ts';
const root = path.dirname(fileURLToPath(import.meta.url));
const repoRequire = createRequire('C:/nx-close/package.json');
const { JSDOM } = repoRequire('jsdom');
const iso = repoRequire('isomorphic-dompurify');
const domEntry = repoRequire.resolve('dompurify');
assert.equal(iso.version, '3.4.17', 'Production sanitizer must consume the installed patched DOMPurify');
assert.equal(repoRequire('ip-address/package.json').version, '10.7.4');
const maliciousHtml = '<h2>Safe artifact heading</h2><p>Safe paragraph <strong>kept</strong></p><img src="x" onerror="void 0"><script>probeMarker</script><iframe src="https://example.invalid"></iframe><a href="javascript:void(0)">unsafe link</a>';
const maliciousSvg = '<svg xmlns="http://www.w3.org/2000/svg"><text x="10" y="20">Safe diagram</text><circle cx="10" cy="10" r="4"/><script>probeMarker</script><foreignObject><p>blocked</p></foreignObject><a href="javascript:void(0)"><text>unwrapped link</text></a><animate attributeName="href" values="x;javascript:void(0)"/></svg>';
const maliciousMarkdown = '# Safe Markdown\n\n**kept**\n\n<script>probeMarker</script><img src=x onerror="void 0">\n\n[unsafe](javascript:void(0))\n\n[safe](https://example.invalid/path)\n\n```js\nconst n = 1;\n```';
const cases = [
  { name: 'artifact', input: maliciousHtml, output: sanitizeArtifactHtml(maliciousHtml), benign: ['Safe artifact heading', 'Safe paragraph', '<strong>kept</strong>'], forbidden: ['script', 'iframe', 'object', 'embed', 'link', 'meta', 'base', 'style'] },
  { name: 'diagram', input: maliciousSvg, output: sanitizeSvg(maliciousSvg), benign: ['Safe diagram', '<circle'], forbidden: ['script', 'foreignObject', 'animate', 'set', 'a', 'use'] },
  { name: 'markdown', input: maliciousMarkdown, output: renderMarkdown(maliciousMarkdown), benign: ['Safe Markdown', '<strong>kept</strong>', 'https://example.invalid/path', 'code-block', 'copy-btn'], forbidden: ['script', 'iframe', 'object', 'embed', 'img'] },
];
for (const item of cases) {
  const win = new JSDOM(item.output).window;
  for (const tag of item.forbidden) assert.equal(win.document.getElementsByTagName(tag).length, 0, item.name + ' removed ' + tag);
  for (const el of win.document.querySelectorAll('*')) {
    for (const attr of el.attributes) {
      assert.equal(/^on/i.test(attr.name), false, item.name + ' removed event attributes');
      if (/^(?:href|xlink:href)$/i.test(attr.name)) assert.equal(/^javascript:/i.test(attr.value), false);
    }
  }
  for (const safe of item.benign) assert.ok(item.output.includes(safe), item.name + ' retained ' + safe);
  fs.writeFileSync(path.join(root, 'product-' + item.name + '.input.txt'), item.input);
  fs.writeFileSync(path.join(root, 'product-' + item.name + '.html'), item.output);
  win.close();
}
const sources = ['desktop/src/shared/security/sanitizeArtifact.ts', 'desktop/src/shared/security/sanitizeSvg.ts', 'modules/coding/utils/MarkdownRenderer.ts', 'package.json', 'package-lock.json'];
const hash = (file: string) => createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const report = { node: process.version, cwd: process.cwd(), dompurify: iso.version, dompurifyEntry: domEntry, dompurifyEntrySha256: hash(domEntry), ipAddress: repoRequire('ip-address/package.json').version, boundary: 'Actual source exports invoked with Node24 native TypeScript stripping; serialized return markup parsed by jsdom, no event execution or packaged UI navigation', cases: cases.map(c => ({ name: c.name, output: c.output, benignControls: c.benign, prohibitedTags: c.forbidden })), sourceHashes: Object.fromEntries(sources.map(p => [p, hash('C:/nx-close/' + p)])) };
fs.writeFileSync(path.join(root, 'nexus-product-boundary-results.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
