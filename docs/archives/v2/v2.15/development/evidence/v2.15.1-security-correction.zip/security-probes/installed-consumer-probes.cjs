const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { createHash } = require('node:crypto');
const { createRequire } = require('node:module');
const { isIPv6 } = require('node:net');
const req = createRequire('C:/nx-close/package.json');
const hash = (p) => createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const matched = [
  ['dompurify/dist/purify.cjs.js', 'dompurify-3.4.17/package/dist/purify.cjs.js'],
  ['ip-address/dist/ipv6.js', 'ip-address-10.7.4/package/dist/ipv6.js'],
];
const bindings = matched.map(([actual, downloaded]) => {
  const installed = path.join('C:/nx-close/node_modules', actual);
  const packtar = path.join(__dirname, downloaded);
  assert.equal(hash(installed), hash(packtar));
  return { installed, verifiedTarFile: packtar, sha256: hash(installed) };
});
const { ipKeyGenerator } = req('express-rate-limit');
const attack = '%'.repeat(32000) + '\n';
assert.equal(isIPv6(attack), false);
assert.equal(ipKeyGenerator(attack), attack);
const cases = [
  { input: '2001:db8::1', expected: '2001:db8::/56' },
  { input: '::ffff:192.0.2.1', expected: '192.0.2.1' },
  { input: '192.0.2.1', expected: '192.0.2.1' },
];
for (const c of cases) { c.output = ipKeyGenerator(c.input); assert.equal(c.output, c.expected); }
const result = { node: process.version, installedDOMPurify: req('isomorphic-dompurify').version, installedIPAddress: req('ip-address/package.json').version, bindings, rateLimiterHelper: { malformedLength: attack.length, malformedPassesNativeIPv6Check: false, malformedPassedThroughUnchanged: true, cases }, limits: 'Real installed helper invoked; no HTTP endpoint or network request was launched' };
fs.writeFileSync(path.join(__dirname, 'installed-consumer-results.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
