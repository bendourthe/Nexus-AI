# Security Runtime Qualification

This is a private local qualification packet. It does not authorize publication and does not qualify the earlier archive projection after dependency-input changes.

## Upstream API Observations

Four npm registry tarballs are retained with registry metadata. Their SHA512 integrity and SHA1 shasums were verified before safe extraction; no npm lifecycle scripts ran in these private fixtures. The official GitHub advisory JSON snapshots and URLs are in official-advisory-index.json.

The successful command was node advisory-probes-v2.cjs (Node v24.13.0; real installed jsdom29.1.1). The three DOMPurify cases use real factories from the old and new tarballs. Scripts and template expressions are inert markers; no event, template or navigation execution is enabled or claimed. SAFE_FOR_TEMPLATES shadow expressions survive3.4.16 and are removed3.4.17, with an independent safe span retained. Detached-parent and detached-sibling hook cases retain onerror only3.4.16; both patched cases remove it and preserve a safe paragraph. The self-removal control removes the handler in both versions. XHTML href animation metadata survives3.4.16 but is removed3.4.17; safe SVG text remains and ordinary HTML mode rejects it in both.

The original advisory-probes.cjs attempt is preserved with its failing log. Its safe control shared a text node with the template expression and was consequently scrubbed along with that expression. V2 separates the safe span; this was a probe correction, not a production change.

For Address6, repeated-percent-plus-newline invalid inputs of4001,8001,16001 and32001 characters are rejected by both libraries. Median runtimes were respectively5.73,23.78,93.37 and385.24ms in10.7.3 versus0.013,0.014,0.025 and0.038ms in10.7.4. These are descriptive local observations with no timing threshold gate. A separately instrumented exported legacy expression records one call by the real10.7.3 constructor and zero by10.7.4. The instrumentation is restored immediately. Ordinary IPv6, a scoped IPv6 zone, ordinary IPv4 and malformed-address controls retain identical expected API behavior.

## Nexus Source Trace

The direct product consumers are desktop/src/shared/security/sanitizeArtifact.ts, desktop/src/shared/security/sanitizeSvg.ts and modules/coding/utils/MarkdownRenderer.ts. They sanitize markup strings without SAFE_FOR_TEMPLATES, IN_PLACE, PARSER_MEDIA_TYPE or attached DOM input. The SVG profile expressly forbids animate, set, foreignObject and href attributes. Artifact HTML enters InteractiveArtifact through sanitizeArtifactHtml. MermaidDiagram calls sanitizeSvg after Mermaid rendering and diagramExport repeats SVG sanitization before export. MarkdownRenderer output is consumed by extension chat panel controllers. The upstream advisory probes demonstrate the library defects, not a demonstrated Nexus exploit through these source configurations.

Mermaid additionally registers attribute-only target/rel hooks, which do not remove parents or siblings, and sanitizes strings. This is a source inspection, not a claim that every Mermaid plugin or rendered diagram was exercised.

The production ip-address chain is @modelcontextprotocol/sdk1.32.1 -> express-rate-limit8.5.2 -> ip-address. The rate limiter checks node:net.isIPv6 before constructing Address6; the repeated-percent attack input does not pass that check. The Nexus McpServer and McpClient adapters found use stdio transports. No application import of Address6 or SDK OAuth HTTP handler wiring was found. The nested npm-bundled ip-address10.5.0 belongs to development tooling, separately retained in the npm explain receipt. Actual HTTP rate-limiter request reachability and a packaged application session were not demonstrated here.

## Product Boundary Observations

After the installed-byte correction, the fresh command node --experimental-strip-types nexus-product-boundary-v2.mts exited0. It imports actual Nexus source exports through file URLs and attests isomorphic-dompurify.version3.4.17 before invoking them. Artifact HTML, SVG and Markdown malicious inputs were sanitized and serialized into product-artifact.html, product-diagram.html and product-markdown.html, with exact original inputs retained separately. Each output was parsed with real jsdom and checked for the prohibited tags, inline event attributes and javascript hrefs. Harmless artifact headings/paragraph/strong text, SVG diagram text/circle and Markdown headings/strong/link/code controls survived. The source-export API boundary was exercised. A packaged shell session, browser navigation and event execution were not exercised.

The fresh command node installed-consumer-probes.cjs exited0. The actual installed DOMPurify CJS file and Address6 implementation hash-identically to the verified3.4.17/10.7.4 tarballs. The real express-rate-limit ipKeyGenerator API normalizes2001:db8::1 to2001:db8::/56, maps IPv4-mapped IPv6 to192.0.2.1 and preserves ordinary IPv4. The32001-character advisory input fails native isIPv6 and passes through unchanged, consistent with the source guard that prevents it from entering Address6 through this helper. No HTTP endpoint or network request was launched.

The first product-boundary attempt is preserved as a Windows bare-drive ESM URL refusal. The corrected file-URL script then refused the initially installed3.4.16 version, also preserved. Only after the installed dependencies actually changed to3.4.17/10.7.4 was product-boundary-patched.log generated with exit0. These failed attempts are explicitly separate from qualifying output.

## Scope and Remaining Limits

Only newly created private files were written. The five inspected Nexus source modules have unchanged hashes from the initial binding through this final record. Repository source, tests, settings, allowlists, signed state, Git and GitHub state were not modified by this qualification. The coordinator owns package installation, complete suites, source publication and release decisions. The packet binds current modified package inputs, not a published release or tag.

No existing focused tests were duplicated because the coordinator is running full root and desktop suites; those totals must be reported from the coordinator's own evidence. The archive projection qualified before these package-input changes is historical until its receipts are rebound. This packet grants no publication authority and does not waive any approval boundary.
